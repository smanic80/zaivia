-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 26 2018 г., 13:27
-- Версия сервера: 5.7.16
-- Версия PHP: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `zaivia`
--

-- --------------------------------------------------------

--
-- Структура таблицы `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_listings`
--

DROP TABLE IF EXISTS `wp_listings`;
CREATE TABLE `wp_listings` (
  `listing_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `MLSNumber` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `sale_rent` tinyint(1) NOT NULL DEFAULT '0',
  `sale_by` tinyint(1) NOT NULL DEFAULT '0',
  `address` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `unit_number` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `city` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `province` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `zip` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `neighbourhood` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lat` decimal(11,8) DEFAULT NULL,
  `lng` decimal(11,8) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `property_type` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `house_type` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `square_footage` decimal(8,2) NOT NULL DEFAULT '0.00',
  `bedrooms` tinyint(1) NOT NULL DEFAULT '0',
  `bathrooms` tinyint(1) NOT NULL DEFAULT '0',
  `roof_type` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `exterior_type` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `parking` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `driveway` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `size_x` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `size_y` varchar(512) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `size_units` varchar(5) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `year_built` smallint(4) DEFAULT NULL,
  `annual_taxes` decimal(10,2) DEFAULT NULL,
  `condo_fees` decimal(10,2) DEFAULT NULL,
  `partial_rent` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `room_features` text COLLATE utf8mb4_unicode_520_ci,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `featured` tinyint(1) UNSIGNED DEFAULT '0',
  `premium` tinyint(1) UNSIGNED DEFAULT '0',
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `bump_up` tinyint(1) UNSIGNED DEFAULT '0',
  `bump_up_date` timestamp NULL DEFAULT NULL,
  `status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '' COMMENT '0',
  `date_created` datetime DEFAULT NULL,
  `date_published` datetime DEFAULT NULL,
  `activated` tinyint(1) UNSIGNED DEFAULT '0',
  `to_delete` tinyint(1) UNSIGNED DEFAULT '1',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_reason` text COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_listings`
--

INSERT INTO `wp_listings` (`listing_id`, `user_id`, `MLSNumber`, `sale_rent`, `sale_by`, `address`, `unit_number`, `city`, `province`, `zip`, `neighbourhood`, `lat`, `lng`, `price`, `property_type`, `house_type`, `square_footage`, `bedrooms`, `bathrooms`, `roof_type`, `exterior_type`, `parking`, `driveway`, `size_x`, `size_y`, `size_units`, `year_built`, `annual_taxes`, `condo_fees`, `partial_rent`, `room_features`, `description`, `featured`, `premium`, `url`, `bump_up`, `bump_up_date`, `status`, `date_created`, `date_published`, `activated`, `to_delete`, `deleted`, `deleted_reason`) VALUES
(284, 1, '', 0, 0, '46 Street West', '710', 'Saskatoon', 'SK', 'S7L 7M1', 'Division No. 11', '52.16589141', '-106.67919774', '1000.00', 'House', 'Bungalow', '55.00', 6, 3, '', '', 'lots', '', '0', '0', 'ft', 1977, '0.00', '0.00', 'Room;Main Floor', 'a:0:{}', '', 1, 1, '', 1, NULL, 'Active', '2018-02-23 10:27:10', '2018-02-24 20:09:44', 1, 0, 0, NULL),
(285, 1, '', 0, 0, '47 Street West', '710', 'Saskatoon', 'SK', 'S7L 7M1', 'Division No. 11', '52.16696841', '-106.67715154', '500.00', 'House', 'Bungalow', '55.00', 6, 3, '', '', NULL, '', '0', '0', 'ft', 1977, '0.00', '0.00', 'Room;Main Floor', 'a:0:{}', '', 0, 0, '', 0, NULL, 'Active', '2018-02-25 13:14:01', '2018-02-25 13:18:35', 1, 0, 0, NULL),
(286, 1, '', 1, 0, '46 Street West', '710', 'Saskatoon', 'SK', 'S7L 7M1', 'Division No. 11', '52.16627968', '-106.67820800', '1000000.00', 'House', 'Bungalow', '55.00', 6, 3, '', '', '', '', '0', '0', 'ft', 1977, '44.00', '0.00', 'Room;Main Floor', 'a:1:{s:7:\"kitchen\";a:1:{i:0;s:7:\"qaweqwe\";}}', '', 0, 0, '', 0, NULL, 'Active', '2018-02-26 07:59:37', '2018-02-26 07:59:37', 1, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_listing_contact`
--

DROP TABLE IF EXISTS `wp_listing_contact`;
CREATE TABLE `wp_listing_contact` (
  `contact_id` bigint(20) UNSIGNED NOT NULL,
  `listing_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `contact_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_name_show` tinyint(1) NOT NULL DEFAULT '0',
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_phone1` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_phone1_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `contact_phone1_show` tinyint(1) NOT NULL DEFAULT '0',
  `contact_phone2` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_phone2_type` tinyint(1) NOT NULL DEFAULT '0',
  `contact_phone2_show` tinyint(1) NOT NULL DEFAULT '0',
  `contact_title` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_company` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_address` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_city` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contact_zip` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_listing_contact`
--

INSERT INTO `wp_listing_contact` (`contact_id`, `listing_id`, `contact_name`, `contact_name_show`, `contact_email`, `contact_phone1`, `contact_phone1_type`, `contact_phone1_show`, `contact_phone2`, `contact_phone2_type`, `contact_phone2_show`, `contact_title`, `contact_company`, `contact_address`, `contact_city`, `contact_zip`) VALUES
(88, 284, 'Test Tester', 0, 'tester@test.com', '1234567890', 'Cell', 0, '', 0, 0, '', 'Com', 'werqweeefsd', 'wer', 'S7L 7M1'),
(89, 285, 'Test Tester', 0, 'tester@test.com', '1234567890', 'Cell', 0, '', 0, 0, '', 'Com', 'werqweeefsd', 'wer', 'S7L 7M1'),
(90, 286, 'Test Tester', 0, 'tester@test.com', '1234567890', 'Cell', 0, '', 0, 0, '', 'Com', 'werqweeefsd', 'wer', 'S7L 7M1');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_listing_features`
--

DROP TABLE IF EXISTS `wp_listing_features`;
CREATE TABLE `wp_listing_features` (
  `feature_id` bigint(20) UNSIGNED NOT NULL,
  `listing_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `feature_type` tinyint(1) NOT NULL DEFAULT '1',
  `feature_custom` tinyint(1) NOT NULL DEFAULT '0',
  `feature` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_listing_features`
--

INSERT INTO `wp_listing_features` (`feature_id`, `listing_id`, `feature_type`, `feature_custom`, `feature`) VALUES
(1, 286, 1, 0, 'alarm_system'),
(2, 286, 1, 0, 'tennis_court'),
(3, 286, 2, 0, 'Freezer'),
(4, 286, 2, 0, 'Range / Oven'),
(5, 286, 3, 0, 'Underground Sprinklers'),
(6, 286, 3, 0, 'Greenhouse');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_listing_file`
--

DROP TABLE IF EXISTS `wp_listing_file`;
CREATE TABLE `wp_listing_file` (
  `file_id` bigint(20) UNSIGNED NOT NULL,
  `listing_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `media_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `file_type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `pos` int(20) NOT NULL DEFAULT '0',
  `big` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `card` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `thumb` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_listing_file`
--

INSERT INTO `wp_listing_file` (`file_id`, `listing_id`, `media_id`, `file_type`, `confirmed`, `pos`, `big`, `card`, `thumb`) VALUES
(54, 284, 349, 2, 1, 0, '', NULL, NULL),
(56, 284, 351, 3, 1, 0, '', NULL, NULL),
(57, 285, 352, 1, 1, 0, '', NULL, NULL),
(60, 285, 355, 2, 1, 0, '', NULL, NULL),
(61, 286, 356, 1, 1, 0, '', NULL, NULL),
(62, 286, 357, 2, 1, 0, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_listing_openhouse`
--

DROP TABLE IF EXISTS `wp_listing_openhouse`;
CREATE TABLE `wp_listing_openhouse` (
  `openhouse_id` bigint(20) UNSIGNED NOT NULL,
  `listing_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `start_time` time NOT NULL DEFAULT '00:00:00',
  `end_time` time NOT NULL DEFAULT '00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_listing_openhouse`
--

INSERT INTO `wp_listing_openhouse` (`openhouse_id`, `listing_id`, `date`, `start_time`, `end_time`) VALUES
(71, 284, '2018-02-28', '16:30:00', '17:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_listing_rent`
--

DROP TABLE IF EXISTS `wp_listing_rent`;
CREATE TABLE `wp_listing_rent` (
  `rent_id` bigint(20) UNSIGNED NOT NULL,
  `listing_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `rent_date` date NOT NULL,
  `rent_deposit` varchar(30) NOT NULL,
  `rent_furnishings` tinyint(1) NOT NULL,
  `rent_pets` tinyint(1) NOT NULL,
  `rent_smoking` tinyint(1) NOT NULL,
  `rent_laundry` tinyint(1) NOT NULL,
  `rent_electrified_parking` tinyint(1) NOT NULL,
  `rent_secured_entry` tinyint(1) NOT NULL,
  `rent_private_entry` tinyint(1) NOT NULL,
  `rent_onsite` tinyint(1) NOT NULL,
  `rent_utilities` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_listing_rent`
--

INSERT INTO `wp_listing_rent` (`rent_id`, `listing_id`, `rent_date`, `rent_deposit`, `rent_furnishings`, `rent_pets`, `rent_smoking`, `rent_laundry`, `rent_electrified_parking`, `rent_secured_entry`, `rent_private_entry`, `rent_onsite`, `rent_utilities`) VALUES
(8, 284, '2018-02-28', 'fff', 1, 1, 1, 1, 1, 0, 0, 0, 'gas;heat;water;electricity;tv_satellite;internet'),
(9, 285, '2018-02-28', 'fff', 1, 1, 1, 1, 1, 0, 0, 0, 'gas;heat;water;electricity;tv_satellite;internet');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/zaivia', 'yes'),
(2, 'home', 'http://localhost/zaivia', 'yes'),
(3, 'blogname', 'Zaivia', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'smanic80@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:40:\"index.php?&page_id=236&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'zaivia', 'yes'),
(41, 'stylesheet', 'zaivia', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '236', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:6:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:4:\"demo\";a:2:{s:4:\"name\";s:4:\"Demo\";s:12:\"capabilities\";a:44:{s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:18:\"edit_theme_options\";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:15:\"sidebar-default\";a:4:{i:0;s:14:\"recent-posts-2\";i:1;s:17:\"recent-comments-2\";i:2;s:10:\"archives-2\";i:3;s:12:\"categories-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'cron', 'a:5:{i:1519642712;a:3:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1519644999;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519649218;a:1:{s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1519686022;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(109, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1508799627;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(121, 'can_compress_scripts', '1', 'no'),
(135, 'current_theme', 'Zaivia', 'yes'),
(136, 'theme_mods_zaivia', 'a:3:{i:0;b:0;s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:4:{s:8:\"mainmenu\";i:2;s:11:\"footermenu1\";i:3;s:11:\"footermenu2\";i:4;s:11:\"accountmenu\";i:6;}}', 'yes'),
(137, 'theme_switched', '', 'yes'),
(138, 'widget_am_text', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(141, 'recently_activated', 'a:0:{}', 'yes'),
(142, 'acf_version', '5.6.4', 'yes'),
(173, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:18:\"smanic80@gmail.com\";s:7:\"version\";s:5:\"4.8.4\";s:9:\"timestamp\";i:1511987391;}', 'no'),
(189, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(195, 'options_footer_text', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed consectetur adip', 'no'),
(196, '_options_footer_text', 'field_5a18098ba1155', 'no'),
(197, 'options_facebook', 'https://www.facebook.com/weather/', 'no'),
(198, '_options_facebook', 'field_5a1809e7b28ce', 'no'),
(199, 'options_twitter', 'https://twitter.com/EON_SE_en', 'no'),
(200, '_options_twitter', 'field_5a1809fdb28cf', 'no'),
(227, 'category_children', 'a:0:{}', 'yes'),
(294, 'options_google_api_key', 'AIzaSyA323JFdYRZ1OvDt7ihdHOuyZ34TvSNJb8', 'no'),
(295, '_options_google_api_key', 'field_5a233ba171c65', 'no'),
(302, 'options_home_type_0_name', 'House', 'no'),
(303, '_options_home_type_0_name', 'field_5a24700b39412', 'no'),
(304, 'options_home_type_1_name', 'Condo', 'no'),
(305, '_options_home_type_1_name', 'field_5a24700b39412', 'no'),
(306, 'options_home_type_2_name', 'Apartment', 'no'),
(307, '_options_home_type_2_name', 'field_5a24700b39412', 'no'),
(308, 'options_home_type_3_name', 'Townhouse', 'no'),
(309, '_options_home_type_3_name', 'field_5a24700b39412', 'no'),
(310, 'options_home_type_4_name', 'Duplex', 'no'),
(311, '_options_home_type_4_name', 'field_5a24700b39412', 'no'),
(312, 'options_home_type_5_name', 'Modular Home', 'no'),
(313, '_options_home_type_5_name', 'field_5a24700b39412', 'no'),
(314, 'options_home_type_6_name', 'Lot/Land', 'no'),
(315, '_options_home_type_6_name', 'field_5a24700b39412', 'no'),
(318, 'options_home_type', '7', 'no'),
(319, '_options_home_type', 'field_5a24700239411', 'no'),
(320, 'options_bedrooms_0_name', '0', 'no'),
(321, '_options_bedrooms_0_name', 'field_5a2471e969ac9', 'no'),
(322, 'options_bedrooms_1_name', '1', 'no'),
(323, '_options_bedrooms_1_name', 'field_5a2471e969ac9', 'no'),
(324, 'options_bedrooms_2_name', '2', 'no'),
(325, '_options_bedrooms_2_name', 'field_5a2471e969ac9', 'no'),
(326, 'options_bedrooms_3_name', '3', 'no'),
(327, '_options_bedrooms_3_name', 'field_5a2471e969ac9', 'no'),
(328, 'options_bedrooms', '7', 'no'),
(329, '_options_bedrooms', 'field_5a2471e969ac8', 'no'),
(330, 'options_bathrooms_0_name', '0', 'no'),
(331, '_options_bathrooms_0_name', 'field_5a2471f469acb', 'no'),
(332, 'options_bathrooms_1_name', '1', 'no'),
(333, '_options_bathrooms_1_name', 'field_5a2471f469acb', 'no'),
(334, 'options_bathrooms_2_name', '2', 'no'),
(335, '_options_bathrooms_2_name', 'field_5a2471f469acb', 'no'),
(336, 'options_bathrooms_3_name', '3', 'no'),
(337, '_options_bathrooms_3_name', 'field_5a2471f469acb', 'no'),
(338, 'options_bathrooms', '7', 'no'),
(339, '_options_bathrooms', 'field_5a2471f469aca', 'no'),
(370, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(372, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.4-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.4-partial-1.zip\";s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.4\";s:7:\"version\";s:5:\"4.9.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.1\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.4-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.4-partial-1.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.4-rollback-1.zip\";}s:7:\"current\";s:5:\"4.9.4\";s:7:\"version\";s:5:\"4.9.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.1\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1519600608;s:15:\"version_checked\";s:5:\"4.9.1\";s:12:\"translations\";a:0:{}}', 'no'),
(392, 'options_parking_0_name', '1', 'no'),
(393, '_options_parking_0_name', 'field_5a273128be5b2', 'no'),
(394, 'options_parking_1_name', '2', 'no'),
(395, '_options_parking_1_name', 'field_5a273128be5b2', 'no'),
(396, 'options_parking_2_name', '3', 'no'),
(397, '_options_parking_2_name', 'field_5a273128be5b2', 'no'),
(398, 'options_parking_3_name', '4+', 'no'),
(399, '_options_parking_3_name', 'field_5a273128be5b2', 'no'),
(400, 'options_parking', '4', 'no'),
(401, '_options_parking', 'field_5a273128be5b1', 'no'),
(402, 'options_roof_type_0_name', 'Roof Type 1', 'no'),
(403, '_options_roof_type_0_name', 'field_5a27339d34348', 'no'),
(404, 'options_roof_type', '3', 'no'),
(405, '_options_roof_type', 'field_5a27339d34347', 'no'),
(410, 'options_type_of_house', '', 'no'),
(411, '_options_type_of_house', 'field_5a2736e8fe6c9', 'no'),
(412, 'options_roof_type_1_name', 'Roof Type 2', 'no'),
(413, '_options_roof_type_1_name', 'field_5a27339d34348', 'no'),
(414, 'options_roof_type_2_name', 'Roof Type 3', 'no'),
(415, '_options_roof_type_2_name', 'field_5a27339d34348', 'no'),
(416, 'options_exterior_0_name', 'Brick', 'no'),
(417, '_options_exterior_0_name', 'field_5a2737fdb2e0b', 'no'),
(418, 'options_exterior_1_name', 'Wood', 'no'),
(419, '_options_exterior_1_name', 'field_5a2737fdb2e0b', 'no'),
(420, 'options_exterior', '2', 'no'),
(421, '_options_exterior', 'field_5a2737fdb2e0a', 'no'),
(422, 'options_exterior_type_0_name', 'Brick', 'no'),
(423, '_options_exterior_type_0_name', 'field_5a2737fdb2e0b', 'no'),
(424, 'options_exterior_type_1_name', 'Wood', 'no'),
(425, '_options_exterior_type_1_name', 'field_5a2737fdb2e0b', 'no'),
(426, 'options_exterior_type', '2', 'no'),
(427, '_options_exterior_type', 'field_5a2737fdb2e0a', 'no'),
(428, 'options_driveway_0_name', 'Ashphalt', 'no'),
(429, '_options_driveway_0_name', 'field_5a273a094e155', 'no'),
(430, 'options_driveway_1_name', 'Mud', 'no'),
(431, '_options_driveway_1_name', 'field_5a273a094e155', 'no'),
(432, 'options_driveway', '2', 'no'),
(433, '_options_driveway', 'field_5a273a094e154', 'no'),
(434, 'options_size_units_0_name', 'ft', 'no'),
(435, '_options_size_units_0_name', 'field_5a273a98bbea0', 'no'),
(436, 'options_size_units_1_name', 'm', 'no'),
(437, '_options_size_units_1_name', 'field_5a273a98bbea0', 'no'),
(438, 'options_size_units', '2', 'no'),
(439, '_options_size_units', 'field_5a273a98bbe9f', 'no'),
(461, 'options_partial_space_for_rent', '', 'no'),
(462, '_options_partial_space_for_rent', 'field_5a29ceb9ab0d9', 'no'),
(463, 'options_partial_rent_0_name', 'Room', 'no'),
(464, '_options_partial_rent_0_name', 'field_5a29cf58713a1', 'no'),
(465, 'options_partial_rent_1_name', 'Basement', 'no'),
(466, '_options_partial_rent_1_name', 'field_5a29cf58713a1', 'no'),
(467, 'options_partial_rent_2_name', 'Main Floor', 'no'),
(468, '_options_partial_rent_2_name', 'field_5a29cf58713a1', 'no'),
(469, 'options_partial_rent_3_name', 'Upper Level', 'no'),
(470, '_options_partial_rent_3_name', 'field_5a29cf58713a1', 'no'),
(471, 'options_partial_rent', '4', 'no'),
(472, '_options_partial_rent', 'field_5a29cf58713a0', 'no'),
(473, 'options_feartures_1_0_name', 'Assisted Living', 'no'),
(474, '_options_feartures_1_0_name', 'field_5a2a49809ae28', 'no'),
(475, 'options_feartures_1_1_name', '55+ Community', 'no'),
(476, '_options_feartures_1_1_name', 'field_5a2a49809ae28', 'no'),
(477, 'options_feartures_1_2_name', 'Acreage', 'no'),
(478, '_options_feartures_1_2_name', 'field_5a2a49809ae28', 'no'),
(479, 'options_feartures_1_3_name', 'Farm', 'no'),
(480, '_options_feartures_1_3_name', 'field_5a2a49809ae28', 'no'),
(481, 'options_feartures_1_4_name', 'New Construction', 'no'),
(482, '_options_feartures_1_4_name', 'field_5a2a49809ae28', 'no'),
(483, 'options_feartures_1_5_name', 'Walk-out Basement', 'no'),
(484, '_options_feartures_1_5_name', 'field_5a2a49809ae28', 'no'),
(485, 'options_feartures_1_6_name', 'Fireplace', 'no'),
(486, '_options_feartures_1_6_name', 'field_5a2a49809ae28', 'no'),
(487, 'options_feartures_1_7_name', 'Central Air', 'no'),
(488, '_options_feartures_1_7_name', 'field_5a2a49809ae28', 'no'),
(489, 'options_feartures_1_8_name', 'Central Vac', 'no'),
(490, '_options_feartures_1_8_name', 'field_5a2a49809ae28', 'no'),
(491, 'options_feartures_1_9_name', 'Alarm System', 'no'),
(492, '_options_feartures_1_9_name', 'field_5a2a49809ae28', 'no'),
(493, 'options_feartures_1_10_name', 'Gated Community', 'no'),
(494, '_options_feartures_1_10_name', 'field_5a2a49809ae28', 'no'),
(495, 'options_feartures_1_11_name', 'Fitness Center', 'no'),
(496, '_options_feartures_1_11_name', 'field_5a2a49809ae28', 'no'),
(497, 'options_feartures_1_12_name', 'Tennis Court', 'no'),
(498, '_options_feartures_1_12_name', 'field_5a2a49809ae28', 'no'),
(499, 'options_feartures_1_13_name', 'Disabled Access', 'no'),
(500, '_options_feartures_1_13_name', 'field_5a2a49809ae28', 'no'),
(501, 'options_feartures_1_14_name', 'Elevator', 'no'),
(502, '_options_feartures_1_14_name', 'field_5a2a49809ae28', 'no'),
(503, 'options_feartures_1_15_name', 'Revenue Suite', 'no'),
(504, '_options_feartures_1_15_name', 'field_5a2a49809ae28', 'no'),
(505, 'options_feartures_1_16_name', 'Finished Basement', 'no'),
(506, '_options_feartures_1_16_name', 'field_5a2a49809ae28', 'no'),
(507, 'options_feartures_1_17_name', 'Near School', 'no'),
(508, '_options_feartures_1_17_name', 'field_5a2a49809ae28', 'no'),
(509, 'options_feartures_1_18_name', 'Near Amenities', 'no'),
(510, '_options_feartures_1_18_name', 'field_5a2a49809ae28', 'no'),
(511, 'options_feartures_1_19_name', 'Storage', 'no'),
(512, '_options_feartures_1_19_name', 'field_5a2a49809ae28', 'no'),
(513, 'options_feartures_1_20_name', 'Hot Tub', 'no'),
(514, '_options_feartures_1_20_name', 'field_5a2a49809ae28', 'no'),
(515, 'options_feartures_1_21_name', 'Pool', 'no'),
(516, '_options_feartures_1_21_name', 'field_5a2a49809ae28', 'no'),
(517, 'options_feartures_1', '22', 'no'),
(518, '_options_feartures_1', 'field_5a2a49809ae27', 'no'),
(519, 'options_feartures_2_0_name', 'Dishwasher', 'no'),
(520, '_options_feartures_2_0_name', 'field_5a2a49a59ae2a', 'no'),
(521, 'options_feartures_2_1_name', 'Freezer', 'no'),
(522, '_options_feartures_2_1_name', 'field_5a2a49a59ae2a', 'no'),
(523, 'options_feartures_2_2_name', 'Garbage Disposal', 'no'),
(524, '_options_feartures_2_2_name', 'field_5a2a49a59ae2a', 'no'),
(525, 'options_feartures_2_3_name', 'Microwave', 'no'),
(526, '_options_feartures_2_3_name', 'field_5a2a49a59ae2a', 'no'),
(527, 'options_feartures_2_4_name', 'Range / Oven', 'no'),
(528, '_options_feartures_2_4_name', 'field_5a2a49a59ae2a', 'no'),
(529, 'options_feartures_2_5_name', 'Refrigerator', 'no'),
(530, '_options_feartures_2_5_name', 'field_5a2a49a59ae2a', 'no'),
(531, 'options_feartures_2_6_name', 'Trash Compactor', 'no'),
(532, '_options_feartures_2_6_name', 'field_5a2a49a59ae2a', 'no'),
(533, 'options_feartures_2_7_name', 'Washer', 'no'),
(534, '_options_feartures_2_7_name', 'field_5a2a49a59ae2a', 'no'),
(535, 'options_feartures_2_8_name', 'Dryer', 'no'),
(536, '_options_feartures_2_8_name', 'field_5a2a49a59ae2a', 'no'),
(537, 'options_feartures_2_9_name', 'Appliances Negotiable', 'no'),
(538, '_options_feartures_2_9_name', 'field_5a2a49a59ae2a', 'no'),
(539, 'options_feartures_2', '10', 'no'),
(540, '_options_feartures_2', 'field_5a2a49a59ae29', 'no'),
(541, 'options_feartures_3_0_name', 'Waterfront', 'no'),
(542, '_options_feartures_3_0_name', 'field_5a2a49d39ae2c', 'no'),
(543, 'options_feartures_3_1_name', 'Dock', 'no'),
(544, '_options_feartures_3_1_name', 'field_5a2a49d39ae2c', 'no'),
(545, 'options_feartures_3_2_name', 'Landscaped Yard', 'no'),
(546, '_options_feartures_3_2_name', 'field_5a2a49d39ae2c', 'no'),
(547, 'options_feartures_3_3_name', 'BBQ Area', 'no'),
(548, '_options_feartures_3_3_name', 'field_5a2a49d39ae2c', 'no'),
(549, 'options_feartures_3_4_name', 'Deck / Patio', 'no'),
(550, '_options_feartures_3_4_name', 'field_5a2a49d39ae2c', 'no'),
(551, 'options_feartures_3_5_name', 'Balcony', 'no'),
(552, '_options_feartures_3_5_name', 'field_5a2a49d39ae2c', 'no'),
(553, 'options_feartures_3_6_name', 'Porch', 'no'),
(554, '_options_feartures_3_6_name', 'field_5a2a49d39ae2c', 'no'),
(555, 'options_feartures_3_7_name', 'Fenced Yard', 'no'),
(556, '_options_feartures_3_7_name', 'field_5a2a49d39ae2c', 'no'),
(557, 'options_feartures_3_8_name', 'Underground Sprinklers', 'no'),
(558, '_options_feartures_3_8_name', 'field_5a2a49d39ae2c', 'no'),
(559, 'options_feartures_3_9_name', 'Lawn', 'no'),
(560, '_options_feartures_3_9_name', 'field_5a2a49d39ae2c', 'no'),
(561, 'options_feartures_3_10_name', 'Pond', 'no'),
(562, '_options_feartures_3_10_name', 'field_5a2a49d39ae2c', 'no'),
(563, 'options_feartures_3_11_name', 'Garden', 'no'),
(564, '_options_feartures_3_11_name', 'field_5a2a49d39ae2c', 'no'),
(565, 'options_feartures_3_12_name', 'Greenhouse', 'no'),
(566, '_options_feartures_3_12_name', 'field_5a2a49d39ae2c', 'no'),
(567, 'options_feartures_3_13_name', 'RV Parking', 'no'),
(568, '_options_feartures_3_13_name', 'field_5a2a49d39ae2c', 'no'),
(569, 'options_feartures_3', '14', 'no'),
(570, '_options_feartures_3', 'field_5a2a49d39ae2b', 'no'),
(571, 'options_room_feartures_0_name', 'Kitchen', 'no'),
(572, '_options_room_feartures_0_name', 'field_5a2a4a6a9ae2e', 'no'),
(573, 'options_room_feartures_1_name', 'Dining Room', 'no'),
(574, '_options_room_feartures_1_name', 'field_5a2a4a6a9ae2e', 'no'),
(575, 'options_room_feartures_2_name', 'Living Room', 'no'),
(576, '_options_room_feartures_2_name', 'field_5a2a4a6a9ae2e', 'no'),
(577, 'options_room_feartures_3_name', 'Master Bedroom', 'no'),
(578, '_options_room_feartures_3_name', 'field_5a2a4a6a9ae2e', 'no'),
(579, 'options_room_feartures_4_name', 'Main Bath', 'no'),
(580, '_options_room_feartures_4_name', 'field_5a2a4a6a9ae2e', 'no'),
(581, 'options_room_feartures_5_name', '2nd Bedroom', 'no'),
(582, '_options_room_feartures_5_name', 'field_5a2a4a6a9ae2e', 'no'),
(583, 'options_room_feartures_6_name', '3rd Bedroom', 'no'),
(584, '_options_room_feartures_6_name', 'field_5a2a4a6a9ae2e', 'no'),
(585, 'options_room_feartures_7_name', 'Additional Bedrooms', 'no'),
(586, '_options_room_feartures_7_name', 'field_5a2a4a6a9ae2e', 'no'),
(587, 'options_room_feartures_8_name', 'Basement', 'no'),
(588, '_options_room_feartures_8_name', 'field_5a2a4a6a9ae2e', 'no'),
(589, 'options_room_feartures_9_name', 'Yard', 'no'),
(590, '_options_room_feartures_9_name', 'field_5a2a4a6a9ae2e', 'no'),
(591, 'options_room_feartures_10_name', 'Garage', 'no'),
(592, '_options_room_feartures_10_name', 'field_5a2a4a6a9ae2e', 'no'),
(593, 'options_room_feartures_11_name', 'Special Features', 'no'),
(594, '_options_room_feartures_11_name', 'field_5a2a4a6a9ae2e', 'no'),
(595, 'options_room_feartures', '12', 'no'),
(596, '_options_room_feartures', 'field_5a2a4a6a9ae2d', 'no'),
(603, 'options_room_feartures_0_key', 'kitchen', 'no'),
(604, '_options_room_feartures_0_key', 'field_5a2a70d3bd76d', 'no'),
(605, 'options_room_feartures_1_key', 'dining_room', 'no'),
(606, '_options_room_feartures_1_key', 'field_5a2a70d3bd76d', 'no'),
(607, 'options_room_feartures_2_key', 'living_room', 'no'),
(608, '_options_room_feartures_2_key', 'field_5a2a70d3bd76d', 'no'),
(609, 'options_room_feartures_3_key', 'master_bedroom', 'no'),
(610, '_options_room_feartures_3_key', 'field_5a2a70d3bd76d', 'no'),
(611, 'options_room_feartures_4_key', 'main_bath', 'no'),
(612, '_options_room_feartures_4_key', 'field_5a2a70d3bd76d', 'no'),
(613, 'options_room_feartures_5_key', '2nd_bedroom', 'no'),
(614, '_options_room_feartures_5_key', 'field_5a2a70d3bd76d', 'no'),
(615, 'options_room_feartures_6_key', '3nd_bedroom', 'no'),
(616, '_options_room_feartures_6_key', 'field_5a2a70d3bd76d', 'no'),
(617, 'options_room_feartures_7_key', 'additional_bedrooms', 'no'),
(618, '_options_room_feartures_7_key', 'field_5a2a70d3bd76d', 'no'),
(619, 'options_room_feartures_8_key', 'basement', 'no'),
(620, '_options_room_feartures_8_key', 'field_5a2a70d3bd76d', 'no'),
(621, 'options_room_feartures_9_key', 'yard', 'no'),
(622, '_options_room_feartures_9_key', 'field_5a2a70d3bd76d', 'no'),
(623, 'options_room_feartures_10_key', 'garage', 'no'),
(624, '_options_room_feartures_10_key', 'field_5a2a70d3bd76d', 'no'),
(625, 'options_room_feartures_11_key', 'special_fFeatures', 'no'),
(626, '_options_room_feartures_11_key', 'field_5a2a70d3bd76d', 'no'),
(635, 'options_room_features_0_name', 'Kitchen', 'no'),
(636, '_options_room_features_0_name', 'field_5a2c3e1b3cdea', 'no'),
(637, 'options_room_features_0_key', 'kitchen', 'no'),
(638, '_options_room_features_0_key', 'field_5a2c3e1b3cdeb', 'no'),
(639, 'options_room_features_1_name', 'Dining Room', 'no'),
(640, '_options_room_features_1_name', 'field_5a2c3e1b3cdea', 'no'),
(641, 'options_room_features_1_key', 'dining_room', 'no'),
(642, '_options_room_features_1_key', 'field_5a2c3e1b3cdeb', 'no'),
(643, 'options_room_features_2_name', 'Living Room', 'no'),
(644, '_options_room_features_2_name', 'field_5a2c3e1b3cdea', 'no'),
(645, 'options_room_features_2_key', 'living_room', 'no'),
(646, '_options_room_features_2_key', 'field_5a2c3e1b3cdeb', 'no'),
(647, 'options_room_features_3_name', 'Master Bedroom', 'no'),
(648, '_options_room_features_3_name', 'field_5a2c3e1b3cdea', 'no'),
(649, 'options_room_features_3_key', 'master_bedroom', 'no'),
(650, '_options_room_features_3_key', 'field_5a2c3e1b3cdeb', 'no'),
(651, 'options_room_features_4_name', 'Main Bath', 'no'),
(652, '_options_room_features_4_name', 'field_5a2c3e1b3cdea', 'no'),
(653, 'options_room_features_4_key', 'main_bath', 'no'),
(654, '_options_room_features_4_key', 'field_5a2c3e1b3cdeb', 'no'),
(655, 'options_room_features_5_name', '2nd Bedroom', 'no'),
(656, '_options_room_features_5_name', 'field_5a2c3e1b3cdea', 'no'),
(657, 'options_room_features_5_key', '2nd_bedroom', 'no'),
(658, '_options_room_features_5_key', 'field_5a2c3e1b3cdeb', 'no'),
(659, 'options_room_features_6_name', '3rd Bedroom', 'no'),
(660, '_options_room_features_6_name', 'field_5a2c3e1b3cdea', 'no'),
(661, 'options_room_features_6_key', '3nd_bedroom', 'no'),
(662, '_options_room_features_6_key', 'field_5a2c3e1b3cdeb', 'no'),
(663, 'options_room_features_7_name', 'Additional Bedrooms', 'no'),
(664, '_options_room_features_7_name', 'field_5a2c3e1b3cdea', 'no'),
(665, 'options_room_features_7_key', 'additional_bedrooms', 'no'),
(666, '_options_room_features_7_key', 'field_5a2c3e1b3cdeb', 'no'),
(667, 'options_room_features_8_name', 'Basement', 'no'),
(668, '_options_room_features_8_name', 'field_5a2c3e1b3cdea', 'no'),
(669, 'options_room_features_8_key', 'basement', 'no'),
(670, '_options_room_features_8_key', 'field_5a2c3e1b3cdeb', 'no'),
(671, 'options_room_features_9_name', 'Yard', 'no'),
(672, '_options_room_features_9_name', 'field_5a2c3e1b3cdea', 'no'),
(673, 'options_room_features_9_key', 'yard', 'no'),
(674, '_options_room_features_9_key', 'field_5a2c3e1b3cdeb', 'no'),
(675, 'options_room_features_10_name', 'Garage', 'no'),
(676, '_options_room_features_10_name', 'field_5a2c3e1b3cdea', 'no'),
(677, 'options_room_features_10_key', 'garage', 'no'),
(678, '_options_room_features_10_key', 'field_5a2c3e1b3cdeb', 'no'),
(679, 'options_room_features_11_name', 'Special Features', 'no'),
(680, '_options_room_features_11_name', 'field_5a2c3e1b3cdea', 'no'),
(681, 'options_room_features_11_key', 'special_features', 'no'),
(682, '_options_room_features_11_key', 'field_5a2c3e1b3cdeb', 'no'),
(683, 'options_room_features', '12', 'no'),
(684, '_options_room_features', 'field_5a2c3e1b3cde9', 'no'),
(685, 'options_features_1_0_name', 'Assisted Living', 'no'),
(686, '_options_features_1_0_name', 'field_5a2c5a72a5506', 'no'),
(687, 'options_features_1_1_name', '55+ Community', 'no'),
(688, '_options_features_1_1_name', 'field_5a2c5a72a5506', 'no'),
(689, 'options_features_1_2_name', 'Acreage', 'no'),
(690, '_options_features_1_2_name', 'field_5a2c5a72a5506', 'no'),
(691, 'options_features_1_3_name', 'Farm', 'no'),
(692, '_options_features_1_3_name', 'field_5a2c5a72a5506', 'no'),
(693, 'options_features_1_4_name', 'New Construction', 'no'),
(694, '_options_features_1_4_name', 'field_5a2c5a72a5506', 'no'),
(695, 'options_features_1_5_name', 'Walk-out Basement', 'no'),
(696, '_options_features_1_5_name', 'field_5a2c5a72a5506', 'no'),
(697, 'options_features_1_6_name', 'Fireplace', 'no'),
(698, '_options_features_1_6_name', 'field_5a2c5a72a5506', 'no'),
(699, 'options_features_1_7_name', 'Central Air', 'no'),
(700, '_options_features_1_7_name', 'field_5a2c5a72a5506', 'no'),
(701, 'options_features_1_8_name', 'Central Vac', 'no'),
(702, '_options_features_1_8_name', 'field_5a2c5a72a5506', 'no'),
(703, 'options_features_1_9_name', 'Alarm System', 'no'),
(704, '_options_features_1_9_name', 'field_5a2c5a72a5506', 'no'),
(705, 'options_features_1_10_name', 'Gated Community', 'no'),
(706, '_options_features_1_10_name', 'field_5a2c5a72a5506', 'no'),
(707, 'options_features_1_11_name', 'Fitness Center', 'no'),
(708, '_options_features_1_11_name', 'field_5a2c5a72a5506', 'no'),
(709, 'options_features_1_12_name', 'Tennis Court', 'no'),
(710, '_options_features_1_12_name', 'field_5a2c5a72a5506', 'no'),
(711, 'options_features_1_13_name', 'Disabled Access', 'no'),
(712, '_options_features_1_13_name', 'field_5a2c5a72a5506', 'no'),
(713, 'options_features_1_14_name', 'Elevator', 'no'),
(714, '_options_features_1_14_name', 'field_5a2c5a72a5506', 'no'),
(715, 'options_features_1_15_name', 'Revenue Suite', 'no'),
(716, '_options_features_1_15_name', 'field_5a2c5a72a5506', 'no'),
(717, 'options_features_1_16_name', 'Finished Basement', 'no'),
(718, '_options_features_1_16_name', 'field_5a2c5a72a5506', 'no'),
(719, 'options_features_1_17_name', 'Near School', 'no'),
(720, '_options_features_1_17_name', 'field_5a2c5a72a5506', 'no'),
(721, 'options_features_1_18_name', 'Near Amenities', 'no'),
(722, '_options_features_1_18_name', 'field_5a2c5a72a5506', 'no'),
(723, 'options_features_1_19_name', 'Storage', 'no'),
(724, '_options_features_1_19_name', 'field_5a2c5a72a5506', 'no'),
(725, 'options_features_1_20_name', 'Hot Tub', 'no'),
(726, '_options_features_1_20_name', 'field_5a2c5a72a5506', 'no'),
(727, 'options_features_1_21_name', 'Pool', 'no'),
(728, '_options_features_1_21_name', 'field_5a2c5a72a5506', 'no'),
(731, 'options_features_1', '22', 'no'),
(732, '_options_features_1', 'field_5a2c5a72a5505', 'no'),
(733, 'options_features_2_0_name', 'Dishwasher', 'no'),
(734, '_options_features_2_0_name', 'field_5a2c5a88a5508', 'no'),
(735, 'options_features_2_1_name', 'Freezer', 'no'),
(736, '_options_features_2_1_name', 'field_5a2c5a88a5508', 'no'),
(737, 'options_features_2_2_name', 'Garbage Disposal', 'no'),
(738, '_options_features_2_2_name', 'field_5a2c5a88a5508', 'no'),
(739, 'options_features_2_3_name', 'Microwave', 'no'),
(740, '_options_features_2_3_name', 'field_5a2c5a88a5508', 'no'),
(741, 'options_features_2_4_name', 'Range / Oven', 'no'),
(742, '_options_features_2_4_name', 'field_5a2c5a88a5508', 'no'),
(743, 'options_features_2_5_name', 'Refrigerator', 'no'),
(744, '_options_features_2_5_name', 'field_5a2c5a88a5508', 'no'),
(745, 'options_features_2_6_name', 'Trash Compactor', 'no'),
(746, '_options_features_2_6_name', 'field_5a2c5a88a5508', 'no'),
(747, 'options_features_2_7_name', 'Washer', 'no'),
(748, '_options_features_2_7_name', 'field_5a2c5a88a5508', 'no'),
(749, 'options_features_2_8_name', 'Dryer', 'no'),
(750, '_options_features_2_8_name', 'field_5a2c5a88a5508', 'no'),
(751, 'options_features_2_9_name', 'Appliances Negotiable', 'no'),
(752, '_options_features_2_9_name', 'field_5a2c5a88a5508', 'no'),
(753, 'options_features_2', '10', 'no'),
(754, '_options_features_2', 'field_5a2c5a88a5507', 'no'),
(755, 'options_features_3_0_name', 'Waterfront', 'no'),
(756, '_options_features_3_0_name', 'field_5a2c5a9ca550a', 'no'),
(757, 'options_features_3_1_name', 'Dock', 'no'),
(758, '_options_features_3_1_name', 'field_5a2c5a9ca550a', 'no'),
(759, 'options_features_3_2_name', 'Landscaped Yard', 'no'),
(760, '_options_features_3_2_name', 'field_5a2c5a9ca550a', 'no'),
(761, 'options_features_3_3_name', 'BBQ Area', 'no'),
(762, '_options_features_3_3_name', 'field_5a2c5a9ca550a', 'no'),
(763, 'options_features_3_4_name', 'Deck / Patio', 'no'),
(764, '_options_features_3_4_name', 'field_5a2c5a9ca550a', 'no'),
(765, 'options_features_3_5_name', 'Balcony', 'no'),
(766, '_options_features_3_5_name', 'field_5a2c5a9ca550a', 'no'),
(767, 'options_features_3_6_name', 'Porch', 'no'),
(768, '_options_features_3_6_name', 'field_5a2c5a9ca550a', 'no'),
(769, 'options_features_3_7_name', 'Fenced Yard', 'no'),
(770, '_options_features_3_7_name', 'field_5a2c5a9ca550a', 'no'),
(771, 'options_features_3_8_name', 'Underground Sprinklers', 'no'),
(772, '_options_features_3_8_name', 'field_5a2c5a9ca550a', 'no'),
(773, 'options_features_3_9_name', 'Lawn', 'no'),
(774, '_options_features_3_9_name', 'field_5a2c5a9ca550a', 'no'),
(775, 'options_features_3_10_name', 'Pond', 'no'),
(776, '_options_features_3_10_name', 'field_5a2c5a9ca550a', 'no'),
(777, 'options_features_3_11_name', 'Garden', 'no'),
(778, '_options_features_3_11_name', 'field_5a2c5a9ca550a', 'no'),
(779, 'options_features_3_12_name', 'Greenhouse', 'no'),
(780, '_options_features_3_12_name', 'field_5a2c5a9ca550a', 'no'),
(781, 'options_features_3_13_name', 'RV Parking', 'no'),
(782, '_options_features_3_13_name', 'field_5a2c5a9ca550a', 'no'),
(783, 'options_features_3', '14', 'no'),
(784, '_options_features_3', 'field_5a2c5a9ca5509', 'no'),
(814, 'options_house_type_0_name', 'Bungalow', 'no'),
(815, '_options_house_type_0_name', 'field_5a2d5a94790a2', 'no'),
(816, 'options_house_type_1_name', 'Raised Bungalow', 'no'),
(817, '_options_house_type_1_name', 'field_5a2d5a94790a2', 'no'),
(818, 'options_house_type', '5', 'no'),
(819, '_options_house_type', 'field_5a2d5a94790a1', 'no'),
(890, 'options_rent_utilities_0_name', 'Gas', 'no'),
(891, '_options_rent_utilities_0_name', 'field_5a311c07466d1', 'no'),
(892, 'options_rent_utilities_0_key', 'gas', 'no'),
(893, '_options_rent_utilities_0_key', 'field_5a311c15466d2', 'no'),
(894, 'options_rent_utilities_1_name', 'Heat', 'no'),
(895, '_options_rent_utilities_1_name', 'field_5a311c07466d1', 'no'),
(896, 'options_rent_utilities_1_key', 'heat', 'no'),
(897, '_options_rent_utilities_1_key', 'field_5a311c15466d2', 'no'),
(898, 'options_rent_utilities_2_name', 'Water', 'no'),
(899, '_options_rent_utilities_2_name', 'field_5a311c07466d1', 'no'),
(900, 'options_rent_utilities_2_key', 'water', 'no'),
(901, '_options_rent_utilities_2_key', 'field_5a311c15466d2', 'no'),
(902, 'options_rent_utilities_3_name', 'Electricity', 'no'),
(903, '_options_rent_utilities_3_name', 'field_5a311c07466d1', 'no'),
(904, 'options_rent_utilities_3_key', 'electricity', 'no'),
(905, '_options_rent_utilities_3_key', 'field_5a311c15466d2', 'no'),
(906, 'options_rent_utilities_4_name', 'Cable TV / Satellite', 'no'),
(907, '_options_rent_utilities_4_name', 'field_5a311c07466d1', 'no'),
(908, 'options_rent_utilities_4_key', 'tv_satellite', 'no'),
(909, '_options_rent_utilities_4_key', 'field_5a311c15466d2', 'no'),
(910, 'options_rent_utilities_5_name', 'Internet Access', 'no'),
(911, '_options_rent_utilities_5_name', 'field_5a311c07466d1', 'no'),
(912, 'options_rent_utilities_5_key', 'internet', 'no'),
(913, '_options_rent_utilities_5_key', 'field_5a311c15466d2', 'no'),
(914, 'options_rent_utilities', '6', 'no'),
(915, '_options_rent_utilities', 'field_5a311b7d466cf', 'no'),
(1079, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1519600610;s:7:\"checked\";a:1:{s:6:\"zaivia\";s:3:\"1.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(1084, 'options_page_buy', '288', 'no'),
(1085, '_options_page_buy', 'field_5a44e2e8e5f9f', 'no'),
(1086, 'options_page_rent', '242', 'no'),
(1087, '_options_page_rent', 'field_5a44e347e5fa0', 'no'),
(1088, 'options_page_mylistings', '77', 'no'),
(1089, '_options_page_mylistings', 'field_5a44e35ce5fa1', 'no'),
(1090, 'options_page_postlisting', '94', 'no'),
(1091, '_options_page_postlisting', 'field_5a44e390e5fa3', 'no'),
(1218, 'options_bedrooms_4_name', '4', 'no'),
(1219, '_options_bedrooms_4_name', 'field_5a2471e969ac9', 'no'),
(1220, 'options_bedrooms_5_name', '5', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1221, '_options_bedrooms_5_name', 'field_5a2471e969ac9', 'no'),
(1222, 'options_bedrooms_6_name', '6', 'no'),
(1223, '_options_bedrooms_6_name', 'field_5a2471e969ac9', 'no'),
(1238, 'options_features_1_0_key', 'assisted_living', 'no'),
(1239, '_options_features_1_0_key', 'field_5a5765ec731cd', 'no'),
(1240, 'options_features_1_0_show_in_filter', '1', 'no'),
(1241, '_options_features_1_0_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1242, 'options_features_1_1_key', '55_community', 'no'),
(1243, '_options_features_1_1_key', 'field_5a5765ec731cd', 'no'),
(1244, 'options_features_1_1_show_in_filter', '1', 'no'),
(1245, '_options_features_1_1_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1246, 'options_features_1_2_key', 'acreage', 'no'),
(1247, '_options_features_1_2_key', 'field_5a5765ec731cd', 'no'),
(1248, 'options_features_1_2_show_in_filter', '0', 'no'),
(1249, '_options_features_1_2_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1250, 'options_features_1_3_key', 'farm', 'no'),
(1251, '_options_features_1_3_key', 'field_5a5765ec731cd', 'no'),
(1252, 'options_features_1_3_show_in_filter', '0', 'no'),
(1253, '_options_features_1_3_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1254, 'options_features_1_4_key', 'new_construction', 'no'),
(1255, '_options_features_1_4_key', 'field_5a5765ec731cd', 'no'),
(1256, 'options_features_1_4_show_in_filter', '1', 'no'),
(1257, '_options_features_1_4_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1258, 'options_features_1_5_key', 'walk_out_basement', 'no'),
(1259, '_options_features_1_5_key', 'field_5a5765ec731cd', 'no'),
(1260, 'options_features_1_5_show_in_filter', '0', 'no'),
(1261, '_options_features_1_5_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1262, 'options_features_1_6_key', 'fireplace', 'no'),
(1263, '_options_features_1_6_key', 'field_5a5765ec731cd', 'no'),
(1264, 'options_features_1_6_show_in_filter', '0', 'no'),
(1265, '_options_features_1_6_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1266, 'options_features_1_7_key', 'central_air', 'no'),
(1267, '_options_features_1_7_key', 'field_5a5765ec731cd', 'no'),
(1268, 'options_features_1_7_show_in_filter', '1', 'no'),
(1269, '_options_features_1_7_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1270, 'options_features_1_8_key', 'central_vac', 'no'),
(1271, '_options_features_1_8_key', 'field_5a5765ec731cd', 'no'),
(1272, 'options_features_1_8_show_in_filter', '1', 'no'),
(1273, '_options_features_1_8_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1274, 'options_features_1_9_key', 'alarm_system', 'no'),
(1275, '_options_features_1_9_key', 'field_5a5765ec731cd', 'no'),
(1276, 'options_features_1_9_show_in_filter', '0', 'no'),
(1277, '_options_features_1_9_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1278, 'options_features_1_10_key', 'gated_community', 'no'),
(1279, '_options_features_1_10_key', 'field_5a5765ec731cd', 'no'),
(1280, 'options_features_1_10_show_in_filter', '0', 'no'),
(1281, '_options_features_1_10_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1282, 'options_features_1_11_key', 'fitness_center', 'no'),
(1283, '_options_features_1_11_key', 'field_5a5765ec731cd', 'no'),
(1284, 'options_features_1_11_show_in_filter', '0', 'no'),
(1285, '_options_features_1_11_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1286, 'options_features_1_12_key', 'tennis_court', 'no'),
(1287, '_options_features_1_12_key', 'field_5a5765ec731cd', 'no'),
(1288, 'options_features_1_12_show_in_filter', '0', 'no'),
(1289, '_options_features_1_12_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1290, 'options_features_1_13_key', 'disabled_access', 'no'),
(1291, '_options_features_1_13_key', 'field_5a5765ec731cd', 'no'),
(1292, 'options_features_1_13_show_in_filter', '0', 'no'),
(1293, '_options_features_1_13_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1294, 'options_features_1_14_key', 'elevator', 'no'),
(1295, '_options_features_1_14_key', 'field_5a5765ec731cd', 'no'),
(1296, 'options_features_1_14_show_in_filter', '0', 'no'),
(1297, '_options_features_1_14_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1298, 'options_features_1_15_key', 'revenue_suite', 'no'),
(1299, '_options_features_1_15_key', 'field_5a5765ec731cd', 'no'),
(1300, 'options_features_1_15_show_in_filter', '1', 'no'),
(1301, '_options_features_1_15_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1302, 'options_features_1_16_key', 'finished_basement', 'no'),
(1303, '_options_features_1_16_key', 'field_5a5765ec731cd', 'no'),
(1304, 'options_features_1_16_show_in_filter', '1', 'no'),
(1305, '_options_features_1_16_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1306, 'options_features_1_17_key', 'near_school', 'no'),
(1307, '_options_features_1_17_key', 'field_5a5765ec731cd', 'no'),
(1308, 'options_features_1_17_show_in_filter', '0', 'no'),
(1309, '_options_features_1_17_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1310, 'options_features_1_18_key', 'near_amenities', 'no'),
(1311, '_options_features_1_18_key', 'field_5a5765ec731cd', 'no'),
(1312, 'options_features_1_18_show_in_filter', '0', 'no'),
(1313, '_options_features_1_18_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1314, 'options_features_1_19_key', 'storage', 'no'),
(1315, '_options_features_1_19_key', 'field_5a5765ec731cd', 'no'),
(1316, 'options_features_1_19_show_in_filter', '0', 'no'),
(1317, '_options_features_1_19_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1318, 'options_features_1_20_key', 'hot_tub', 'no'),
(1319, '_options_features_1_20_key', 'field_5a5765ec731cd', 'no'),
(1320, 'options_features_1_20_show_in_filter', '1', 'no'),
(1321, '_options_features_1_20_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1322, 'options_features_1_21_key', 'pool', 'no'),
(1323, '_options_features_1_21_key', 'field_5a5765ec731cd', 'no'),
(1324, 'options_features_1_21_show_in_filter', '1', 'no'),
(1325, '_options_features_1_21_show_in_filter', 'field_5a5765fd731ce', 'no'),
(1483, 'options_page_account_activated', '328', 'no'),
(1484, '_options_page_account_activated', 'field_5a7058361678f', 'no'),
(1486, 'options_create_account_title', 'It\'s Fast Easy and Free', 'no'),
(1487, '_options_create_account_title', 'field_5a705885b4c58', 'no'),
(1488, 'options_create_account_text', 'Creating an account is required to post a listing and advertise your business', 'no'),
(1489, '_options_create_account_text', 'field_5a705890b4c59', 'no'),
(1490, 'options_create_account_subscribe', 'I agree to allow Zaivia to contact me about information pertaining to my account and any other offer', 'no'),
(1491, '_options_create_account_subscribe', 'field_5a70589db4c5a', 'no'),
(1492, 'options_create_account_terms', 'By clicking create account you agree to out website terms of use, our privacy policy and concent to cookies being store on your device', 'no'),
(1493, '_options_create_account_terms', 'field_5a7058a9b4c5b', 'no'),
(1494, 'options_restore_pass_title', 'Forgot Password', 'no'),
(1495, '_options_restore_pass_title', 'field_5a7058bfb4c5d', 'no'),
(1496, 'options_restore_pass_text', 'Enter the email address you used to create a Zaivia account with below. We will then email the instructions for setting your new password for you.', 'no'),
(1497, '_options_restore_pass_text', 'field_5a7058d8b4c5e', 'no'),
(1498, 'options_restore_confirmation', 'Email sent', 'no'),
(1499, '_options_restore_confirmation', 'field_5a7058e8b4c5f', 'no'),
(1537, '_site_transient_timeout_browser_2502d8a009196a678ffa1eb36d6bb2e0', '1519905643', 'no'),
(1538, '_site_transient_browser_2502d8a009196a678ffa1eb36d6bb2e0', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"64.0.3282.167\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(1574, 'options_property_type_0_name', 'House', 'no'),
(1575, '_options_property_type_0_name', 'field_5a24700b39412', 'no'),
(1576, 'options_property_type_1_name', 'Condo', 'no'),
(1577, '_options_property_type_1_name', 'field_5a24700b39412', 'no'),
(1578, 'options_property_type_2_name', 'Apartment', 'no'),
(1579, '_options_property_type_2_name', 'field_5a24700b39412', 'no'),
(1580, 'options_property_type_3_name', 'Townhouse', 'no'),
(1581, '_options_property_type_3_name', 'field_5a24700b39412', 'no'),
(1582, 'options_property_type_4_name', 'Duplex', 'no'),
(1583, '_options_property_type_4_name', 'field_5a24700b39412', 'no'),
(1584, 'options_property_type_5_name', 'Modular Home', 'no'),
(1585, '_options_property_type_5_name', 'field_5a24700b39412', 'no'),
(1586, 'options_property_type_6_name', 'Lot / Land', 'no'),
(1587, '_options_property_type_6_name', 'field_5a24700b39412', 'no'),
(1588, 'options_property_type', '7', 'no'),
(1589, '_options_property_type', 'field_5a24700239411', 'no'),
(1590, 'options_house_type_2_name', 'Bi-Level', 'no'),
(1591, '_options_house_type_2_name', 'field_5a2d5a94790a2', 'no'),
(1592, 'options_house_type_3_name', '2 Story', 'no'),
(1593, '_options_house_type_3_name', 'field_5a2d5a94790a2', 'no'),
(1594, 'options_house_type_4_name', 'Split Level', 'no'),
(1595, '_options_house_type_4_name', 'field_5a2d5a94790a2', 'no'),
(1613, 'options_bathrooms_4_name', '4', 'no'),
(1614, '_options_bathrooms_4_name', 'field_5a2471f469acb', 'no'),
(1615, 'options_bathrooms_5_name', '5', 'no'),
(1616, '_options_bathrooms_5_name', 'field_5a2471f469acb', 'no'),
(1617, 'options_bathrooms_6_name', '6', 'no'),
(1618, '_options_bathrooms_6_name', 'field_5a2471f469acb', 'no'),
(1627, '_site_transient_timeout_theme_roots', '1519602406', 'no'),
(1628, '_site_transient_theme_roots', 'a:1:{s:6:\"zaivia\";s:7:\"/themes\";}', 'no'),
(1630, '_site_transient_update_plugins', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1519600610;s:8:\"response\";a:6:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.3\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.3.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:7:\"default\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";s:7:\"default\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:45:\"taxonomy-terms-order/taxonomy-terms-order.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:34:\"w.org/plugins/taxonomy-terms-order\";s:4:\"slug\";s:20:\"taxonomy-terms-order\";s:6:\"plugin\";s:45:\"taxonomy-terms-order/taxonomy-terms-order.php\";s:11:\"new_version\";s:5:\"1.5.3\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/taxonomy-terms-order/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/taxonomy-terms-order.1.5.3.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:73:\"https://ps.w.org/taxonomy-terms-order/assets/icon-128x128.png?rev=1564412\";s:2:\"2x\";s:73:\"https://ps.w.org/taxonomy-terms-order/assets/icon-256x256.png?rev=1564412\";s:7:\"default\";s:73:\"https://ps.w.org/taxonomy-terms-order/assets/icon-256x256.png?rev=1564412\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:76:\"https://ps.w.org/taxonomy-terms-order/assets/banner-1544x500.png?rev=1564412\";s:2:\"1x\";s:75:\"https://ps.w.org/taxonomy-terms-order/assets/banner-772x250.png?rev=1564412\";s:7:\"default\";s:76:\"https://ps.w.org/taxonomy-terms-order/assets/banner-1544x500.png?rev=1564412\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"post-types-order/post-types-order.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:30:\"w.org/plugins/post-types-order\";s:4:\"slug\";s:16:\"post-types-order\";s:6:\"plugin\";s:37:\"post-types-order/post-types-order.php\";s:11:\"new_version\";s:7:\"1.9.3.6\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/post-types-order/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/post-types-order.1.9.3.6.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:69:\"https://ps.w.org/post-types-order/assets/icon-128x128.png?rev=1226428\";s:7:\"default\";s:69:\"https://ps.w.org/post-types-order/assets/icon-128x128.png?rev=1226428\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:72:\"https://ps.w.org/post-types-order/assets/banner-1544x500.png?rev=1675574\";s:2:\"1x\";s:71:\"https://ps.w.org/post-types-order/assets/banner-772x250.png?rev=1429949\";s:7:\"default\";s:72:\"https://ps.w.org/post-types-order/assets/banner-1544x500.png?rev=1675574\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.1\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:35:\"w.org/plugins/regenerate-thumbnails\";s:4:\"slug\";s:21:\"regenerate-thumbnails\";s:6:\"plugin\";s:47:\"regenerate-thumbnails/regenerate-thumbnails.php\";s:11:\"new_version\";s:5:\"3.0.2\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/regenerate-thumbnails/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/regenerate-thumbnails.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:74:\"https://ps.w.org/regenerate-thumbnails/assets/icon-128x128.png?rev=1753390\";s:7:\"default\";s:74:\"https://ps.w.org/regenerate-thumbnails/assets/icon-128x128.png?rev=1753390\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:77:\"https://ps.w.org/regenerate-thumbnails/assets/banner-1544x500.jpg?rev=1753390\";s:2:\"1x\";s:76:\"https://ps.w.org/regenerate-thumbnails/assets/banner-772x250.jpg?rev=1753390\";s:7:\"default\";s:77:\"https://ps.w.org/regenerate-thumbnails/assets/banner-1544x500.jpg?rev=1753390\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.2\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:29:\"wp-retina-2x/wp-retina-2x.php\";O:8:\"stdClass\":11:{s:2:\"id\";s:26:\"w.org/plugins/wp-retina-2x\";s:4:\"slug\";s:12:\"wp-retina-2x\";s:6:\"plugin\";s:29:\"wp-retina-2x/wp-retina-2x.php\";s:11:\"new_version\";s:5:\"5.2.3\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wp-retina-2x/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wp-retina-2x.5.2.3.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:65:\"https://ps.w.org/wp-retina-2x/assets/icon-128x128.png?rev=1020024\";s:2:\"2x\";s:65:\"https://ps.w.org/wp-retina-2x/assets/icon-256x256.png?rev=1020024\";s:7:\"default\";s:65:\"https://ps.w.org/wp-retina-2x/assets/icon-256x256.png?rev=1020024\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/wp-retina-2x/assets/banner-1544x500.png?rev=699511\";s:2:\"1x\";s:66:\"https://ps.w.org/wp-retina-2x/assets/banner-772x250.png?rev=699511\";s:7:\"default\";s:67:\"https://ps.w.org/wp-retina-2x/assets/banner-1544x500.png?rev=699511\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.1\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:5:\"5.6.8\";s:3:\"url\";s:37:\"https://www.advancedcustomfields.com/\";s:6:\"tested\";s:5:\"4.9.9\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:1:{s:7:\"default\";s:66:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg\";}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:33:\"duplicate-post/duplicate-post.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/duplicate-post\";s:4:\"slug\";s:14:\"duplicate-post\";s:6:\"plugin\";s:33:\"duplicate-post/duplicate-post.php\";s:11:\"new_version\";s:5:\"3.2.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/duplicate-post/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/duplicate-post.3.2.1.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-128x128.png?rev=1612753\";s:2:\"2x\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-256x256.png?rev=1612753\";s:7:\"default\";s:67:\"https://ps.w.org/duplicate-post/assets/icon-256x256.png?rev=1612753\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:69:\"https://ps.w.org/duplicate-post/assets/banner-772x250.png?rev=1612986\";s:7:\"default\";s:69:\"https://ps.w.org/duplicate-post/assets/banner-772x250.png?rev=1612986\";}s:11:\"banners_rtl\";a:0:{}}s:39:\"search-everything/search-everything.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/search-everything\";s:4:\"slug\";s:17:\"search-everything\";s:6:\"plugin\";s:39:\"search-everything/search-everything.php\";s:11:\"new_version\";s:5:\"8.1.9\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/search-everything/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/search-everything.8.1.9.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:2:{s:2:\"1x\";s:71:\"https://ps.w.org/search-everything/assets/banner-772x250.jpg?rev=514450\";s:7:\"default\";s:71:\"https://ps.w.org/search-everything/assets/banner-772x250.jpg?rev=514450\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"wp-migrate-db/wp-migrate-db.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wp-migrate-db\";s:4:\"slug\";s:13:\"wp-migrate-db\";s:6:\"plugin\";s:31:\"wp-migrate-db/wp-migrate-db.php\";s:11:\"new_version\";s:5:\"1.0.2\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wp-migrate-db/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/wp-migrate-db.1.0.2.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:66:\"https://ps.w.org/wp-migrate-db/assets/icon-128x128.jpg?rev=1809889\";s:2:\"2x\";s:66:\"https://ps.w.org/wp-migrate-db/assets/icon-256x256.jpg?rev=1809889\";s:7:\"default\";s:66:\"https://ps.w.org/wp-migrate-db/assets/icon-256x256.jpg?rev=1809889\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:69:\"https://ps.w.org/wp-migrate-db/assets/banner-1544x500.jpg?rev=1809889\";s:2:\"1x\";s:68:\"https://ps.w.org/wp-migrate-db/assets/banner-772x250.jpg?rev=1809889\";s:7:\"default\";s:69:\"https://ps.w.org/wp-migrate-db/assets/banner-1544x500.jpg?rev=1809889\";}s:11:\"banners_rtl\";a:0:{}}s:61:\"wp-performance-score-booster/wp-performance-score-booster.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:42:\"w.org/plugins/wp-performance-score-booster\";s:4:\"slug\";s:28:\"wp-performance-score-booster\";s:6:\"plugin\";s:61:\"wp-performance-score-booster/wp-performance-score-booster.php\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:59:\"https://wordpress.org/plugins/wp-performance-score-booster/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/wp-performance-score-booster.1.9.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:81:\"https://ps.w.org/wp-performance-score-booster/assets/icon-128x128.png?rev=1778586\";s:2:\"2x\";s:81:\"https://ps.w.org/wp-performance-score-booster/assets/icon-256x256.png?rev=1778587\";s:7:\"default\";s:81:\"https://ps.w.org/wp-performance-score-booster/assets/icon-256x256.png?rev=1778587\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:83:\"https://ps.w.org/wp-performance-score-booster/assets/banner-772x250.png?rev=1518992\";s:7:\"default\";s:83:\"https://ps.w.org/wp-performance-score-booster/assets/banner-772x250.png?rev=1518992\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(1631, 'options_search_title', 'Make Yourself at Home!', 'no'),
(1632, '_options_search_title', 'field_5a93de5d3b0fe', 'no'),
(1633, 'options_search_text', 'Search for properties for sale or rent in Canada', 'no'),
(1634, '_options_search_text', 'field_5a93de733b0ff', 'no');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(10, 9, '_edit_last', '1'),
(11, 9, '_wp_page_template', 'default'),
(12, 9, '_edit_lock', '1511523278:1'),
(13, 11, '_edit_last', '1'),
(14, 11, '_wp_page_template', 'default'),
(15, 11, '_edit_lock', '1511523284:1'),
(16, 13, '_edit_last', '1'),
(17, 13, '_edit_lock', '1511524334:1'),
(18, 14, '_menu_item_type', 'post_type'),
(19, 14, '_menu_item_menu_item_parent', '0'),
(20, 14, '_menu_item_object_id', '11'),
(21, 14, '_menu_item_object', 'page'),
(22, 14, '_menu_item_target', ''),
(23, 14, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(24, 14, '_menu_item_xfn', ''),
(25, 14, '_menu_item_url', ''),
(27, 15, '_menu_item_type', 'post_type'),
(28, 15, '_menu_item_menu_item_parent', '0'),
(29, 15, '_menu_item_object_id', '9'),
(30, 15, '_menu_item_object', 'page'),
(31, 15, '_menu_item_target', ''),
(32, 15, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(33, 15, '_menu_item_xfn', ''),
(34, 15, '_menu_item_url', ''),
(54, 13, '_wp_page_template', 'default'),
(55, 19, '_menu_item_type', 'post_type'),
(56, 19, '_menu_item_menu_item_parent', '0'),
(57, 19, '_menu_item_object_id', '13'),
(58, 19, '_menu_item_object', 'page'),
(59, 19, '_menu_item_target', ''),
(60, 19, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(61, 19, '_menu_item_xfn', ''),
(62, 19, '_menu_item_url', ''),
(64, 20, '_menu_item_type', 'custom'),
(65, 20, '_menu_item_menu_item_parent', '0'),
(66, 20, '_menu_item_object_id', '20'),
(67, 20, '_menu_item_object', 'custom'),
(68, 20, '_menu_item_target', ''),
(69, 20, '_menu_item_classes', 'a:2:{i:0;s:10:\"open-modal\";i:1;s:14:\"logout-visible\";}'),
(70, 20, '_menu_item_xfn', ''),
(71, 20, '_menu_item_url', '#login'),
(100, 24, '_menu_item_type', 'post_type'),
(101, 24, '_menu_item_menu_item_parent', '0'),
(102, 24, '_menu_item_object_id', '9'),
(103, 24, '_menu_item_object', 'page'),
(104, 24, '_menu_item_target', ''),
(105, 24, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(106, 24, '_menu_item_xfn', ''),
(107, 24, '_menu_item_url', ''),
(109, 25, '_menu_item_type', 'post_type'),
(110, 25, '_menu_item_menu_item_parent', '0'),
(111, 25, '_menu_item_object_id', '11'),
(112, 25, '_menu_item_object', 'page'),
(113, 25, '_menu_item_target', ''),
(114, 25, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(115, 25, '_menu_item_xfn', ''),
(116, 25, '_menu_item_url', ''),
(118, 26, '_edit_last', '1'),
(119, 26, '_wp_page_template', 'default'),
(120, 26, '_edit_lock', '1511524343:1'),
(121, 28, '_edit_last', '1'),
(122, 28, '_wp_page_template', 'default'),
(123, 28, '_edit_lock', '1511524349:1'),
(124, 30, '_edit_last', '1'),
(125, 30, '_wp_page_template', 'default'),
(126, 30, '_edit_lock', '1511524355:1'),
(127, 32, '_edit_last', '1'),
(128, 32, '_edit_lock', '1511524361:1'),
(129, 32, '_wp_page_template', 'default'),
(130, 34, '_menu_item_type', 'post_type'),
(131, 34, '_menu_item_menu_item_parent', '0'),
(132, 34, '_menu_item_object_id', '26'),
(133, 34, '_menu_item_object', 'page'),
(134, 34, '_menu_item_target', ''),
(135, 34, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(136, 34, '_menu_item_xfn', ''),
(137, 34, '_menu_item_url', ''),
(139, 35, '_menu_item_type', 'post_type'),
(140, 35, '_menu_item_menu_item_parent', '0'),
(141, 35, '_menu_item_object_id', '28'),
(142, 35, '_menu_item_object', 'page'),
(143, 35, '_menu_item_target', ''),
(144, 35, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(145, 35, '_menu_item_xfn', ''),
(146, 35, '_menu_item_url', ''),
(148, 36, '_menu_item_type', 'post_type'),
(149, 36, '_menu_item_menu_item_parent', '0'),
(150, 36, '_menu_item_object_id', '30'),
(151, 36, '_menu_item_object', 'page'),
(152, 36, '_menu_item_target', ''),
(153, 36, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(154, 36, '_menu_item_xfn', ''),
(155, 36, '_menu_item_url', ''),
(157, 37, '_menu_item_type', 'post_type'),
(158, 37, '_menu_item_menu_item_parent', '0'),
(159, 37, '_menu_item_object_id', '32'),
(160, 37, '_menu_item_object', 'page'),
(161, 37, '_menu_item_target', ''),
(162, 37, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(163, 37, '_menu_item_xfn', ''),
(164, 37, '_menu_item_url', ''),
(166, 38, '_edit_last', '1'),
(167, 38, '_edit_lock', '1519640770:1'),
(168, 43, '_edit_last', '1'),
(169, 43, '_edit_lock', '1519640774:1'),
(262, 56, '_wp_attached_file', '2017/10/h4.png'),
(263, 56, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:46;s:6:\"height\";i:43;s:4:\"file\";s:14:\"2017/10/h4.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(264, 57, '_wp_attached_file', '2017/10/h5.png'),
(265, 57, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:40;s:6:\"height\";i:43;s:4:\"file\";s:14:\"2017/10/h5.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(266, 58, '_wp_attached_file', '2017/10/h6.png'),
(267, 58, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:41;s:6:\"height\";i:43;s:4:\"file\";s:14:\"2017/10/h6.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(268, 59, '_wp_attached_file', '2017/10/h7.png'),
(269, 59, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:43;s:6:\"height\";i:43;s:4:\"file\";s:14:\"2017/10/h7.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(430, 77, '_edit_last', '1'),
(431, 77, '_edit_lock', '1512900495:1'),
(432, 77, '_wp_page_template', 'page-templates/my-listings.php'),
(442, 80, '_edit_last', '1'),
(443, 80, '_edit_lock', '1519378426:1'),
(444, 80, '_wp_page_template', 'page-templates/my-profile.php'),
(445, 82, '_edit_last', '1'),
(446, 82, '_wp_page_template', 'default'),
(447, 82, '_edit_lock', '1512369274:1'),
(475, 87, '_edit_last', '1'),
(476, 87, '_edit_lock', '1519383024:1'),
(477, 77, 'button_title', 'List a property for sale or rent - it\'s FREE'),
(478, 77, '_button_title', 'field_5a24f028cc4a3'),
(479, 77, 'button_text', 'List your property'),
(480, 77, '_button_text', 'field_5a24f041531f6'),
(481, 90, 'button_title', 'Post a listing is easy -the'),
(482, 90, '_button_title', 'field_5a24f028cc4a3'),
(483, 90, 'button_text', 'Become a comminuty partner'),
(484, 90, '_button_text', 'field_5a24f041531f6'),
(485, 77, 'table_title', 'My Listings'),
(486, 77, '_table_title', 'field_5a24f0bbb8159'),
(487, 92, 'button_title', 'Post a listing is easy -the'),
(488, 92, '_button_title', 'field_5a24f028cc4a3'),
(489, 92, 'button_text', 'Become a comminuty partner'),
(490, 92, '_button_text', 'field_5a24f041531f6'),
(491, 92, 'table_title', 'My Listings'),
(492, 92, '_table_title', 'field_5a24f0bbb8159'),
(493, 93, 'button_title', 'Post a listing is easy -the'),
(494, 93, '_button_title', 'field_5a24f028cc4a3'),
(495, 93, 'button_text', 'List your property'),
(496, 93, '_button_text', 'field_5a24f041531f6'),
(497, 93, 'table_title', 'My Listings'),
(498, 93, '_table_title', 'field_5a24f0bbb8159'),
(499, 94, '_edit_last', '1'),
(500, 94, '_wp_page_template', 'page-templates/post-listing.php'),
(501, 94, '_edit_lock', '1516272624:1'),
(502, 137, 'button_title', 'List a property for sale or rent - it\'s FREE'),
(503, 137, '_button_title', 'field_5a24f028cc4a3'),
(504, 137, 'button_text', 'List your property'),
(505, 137, '_button_text', 'field_5a24f041531f6'),
(506, 137, 'table_title', 'My Listings'),
(507, 137, '_table_title', 'field_5a24f0bbb8159'),
(508, 144, '_edit_last', '1'),
(509, 144, '_edit_lock', '1519383018:1'),
(510, 94, 'select_draft', 'Would you like to start with one of your previously saved listings?'),
(511, 94, '_select_draft', 'field_5a33c41ae0930'),
(512, 94, 'map_click', 'Click on map to set property location'),
(513, 94, '_map_click', 'field_5a33c487e0931'),
(514, 95, 'select_draft', 'Would you like to start with one of your previously saved listings?'),
(515, 95, '_select_draft', 'field_5a33c41ae0930'),
(516, 95, 'map_click', 'Click on map to set property location'),
(517, 95, '_map_click', 'field_5a33c487e0931'),
(518, 94, 'click_to_select', 'Click on all of the items that apply'),
(519, 94, '_click_to_select', 'field_5a351374e7d28'),
(520, 95, 'click_to_select', 'Click on all of the items that apply'),
(521, 95, '_click_to_select', 'field_5a351374e7d28'),
(522, 94, 'list_up_to_three', 'List up to three items for each of the following areas'),
(523, 94, '_list_up_to_three', 'field_5a35142eccdfe'),
(524, 95, 'list_up_to_three', 'List up to three items for each of the following areas'),
(525, 95, '_list_up_to_three', 'field_5a35142eccdfe'),
(526, 94, 'description', 'Provide a written description of the property'),
(527, 94, '_description', 'field_5a3514799320d'),
(528, 95, 'description', 'Provide a written description of the property'),
(529, 95, '_description', 'field_5a3514799320d'),
(530, 94, 'openhouse', 'Planning an Open House? Why not add this to your listing! If you are not sure of open dates now, you can always add them later through My Zaivia<br>\r\nProvide open house information'),
(531, 94, '_openhouse', 'field_5a3514a33b527'),
(532, 95, 'openhouse', 'Planning an Open House? Why not add this to your listing! If you are not sure of open dates now, you can always add them later through My Zaivia<br>\r\nProvide open house information'),
(533, 95, '_openhouse', 'field_5a3514a33b527'),
(534, 94, 'who_can_be_contacted', 'Who can be contacted about this property? Please ensure the following information is correct and complete'),
(535, 94, '_who_can_be_contacted', 'field_5a35ad0600dd4'),
(536, 94, 'contact_note', 'Note this contact information does not change any other contact information on other listings / contact cards.'),
(537, 94, '_contact_note', 'field_5a35acd9ae4a9'),
(538, 95, 'who_can_be_contacted', 'Who can be contacted about this property? Please ensure the following information is correct and complete'),
(539, 95, '_who_can_be_contacted', 'field_5a35ad0600dd4'),
(540, 95, 'contact_note', 'Note this contact information does not change any other contact information on other listings / contact cards.'),
(541, 95, '_contact_note', 'field_5a35acd9ae4a9'),
(591, 94, 'upload_title', 'Having high quality images as critical for generating interest in your property. Follow our photography tips to enhance your pictures, or check out our Community Partners page to hire a professional photographer. You can upload up to a maximum 30 images.'),
(592, 94, '_upload_title', 'field_5a38f96211ada'),
(593, 94, 'image_title', 'We encourage you to see an external picture of your property as the first picture.'),
(594, 94, '_image_title', 'field_5a38f97811adb'),
(595, 94, 'blueprint_title', 'Upload property blueprints'),
(596, 94, '_blueprint_title', 'field_5a38f98711adc'),
(597, 95, 'upload_title', 'Having high quality images as critical for generating interest in your property. Follow our photography tips to enhance your pictures, or check out our Community Partners page to hire a professional photographer. You can upload up to a maximum 30 images.'),
(598, 95, '_upload_title', 'field_5a38f96211ada'),
(599, 95, 'image_title', 'We encourage you to see an external picture of your property as the first picture.'),
(600, 95, '_image_title', 'field_5a38f97811adb'),
(601, 95, 'blueprint_title', 'Upload property blueprints'),
(602, 95, '_blueprint_title', 'field_5a38f98711adc'),
(603, 94, 'promote_title', 'We off a number of cost effective ways to promote your listings and encrease its exposure. Take a look at our options below.'),
(604, 94, '_promote_title', 'field_5a38fb18bf073'),
(605, 94, 'premium_description', 'Your ad will be highlighted and be identified as one of our Premium Listings. This feature is for users who are looking to promote their ad and increase its exposure.'),
(606, 94, '_premium_description', 'field_5a38fbea81a69'),
(607, 94, 'premium_price', '5'),
(608, 94, '_premium_price', 'field_5a38fd8db4c2a'),
(609, 94, 'featured_description', 'Your ad will be highlighted and be identified as one of our Featured Listings. Featured Listings are randomly selected and posted at the top of each search page. This feature is for users who are looking to promote their ad and increase its exposure.'),
(610, 94, '_featured_description', 'field_5a38fc7af0cef'),
(611, 94, 'featured_price', '10'),
(612, 94, '_featured_price', 'field_5a38fdb3b4c2b'),
(613, 94, 'url_description', 'Your property will be directly linked to an external website using the following'),
(614, 94, '_url_description', 'field_5a38fce6d0f36'),
(615, 94, 'url_price', '3'),
(616, 94, '_url_price', 'field_5a38fdccb4c2c'),
(617, 94, 'bump_description', 'Your ad will be automatically bumped up every 7 days'),
(618, 94, '_bump_description', 'field_5a38fd2f7c1d5'),
(619, 94, 'bump_price', '10'),
(620, 94, '_bump_price', 'field_5a38fdeab4c2d'),
(621, 95, 'promote_title', 'We off a number of cost effective ways to promote your listings and encrease its exposure. Take a look at our options below.'),
(622, 95, '_promote_title', 'field_5a38fb18bf073'),
(623, 95, 'premium_description', 'Your ad will be highlighted and be identified as one of our Premium Listings. This feature is for users who are looking to promote their ad and increase its exposure.'),
(624, 95, '_premium_description', 'field_5a38fbea81a69'),
(625, 95, 'premium_price', '5'),
(626, 95, '_premium_price', 'field_5a38fd8db4c2a'),
(627, 95, 'featured_description', 'Your ad will be highlighted and be identified as one of our Featured Listings. Featured Listings are randomly selected and posted at the top of each search page. This feature is for users who are looking to promote their ad and increase its exposure.'),
(628, 95, '_featured_description', 'field_5a38fc7af0cef'),
(629, 95, 'featured_price', '10'),
(630, 95, '_featured_price', 'field_5a38fdb3b4c2b'),
(631, 95, 'url_description', 'Your property will be directly linked to an external website using the following'),
(632, 95, '_url_description', 'field_5a38fce6d0f36'),
(633, 95, 'url_price', '3'),
(634, 95, '_url_price', 'field_5a38fdccb4c2c'),
(635, 95, 'bump_description', 'Your ad will be automatically bumped up every 7 days'),
(636, 95, '_bump_description', 'field_5a38fd2f7c1d5'),
(637, 95, 'bump_price', '10'),
(638, 95, '_bump_price', 'field_5a38fdeab4c2d'),
(696, 94, 'step6_title', 'Listing Activated'),
(697, 94, '_step6_title', 'field_5a42e5ca7f092'),
(698, 94, 'step6_text', 'Thank you for adding your property to Zaivia'),
(699, 94, '_step6_text', 'field_5a42e5f47f093'),
(700, 94, 'step6_button', 'Back To My Zaivia'),
(701, 94, '_step6_button', 'field_5a42e6077f094'),
(702, 95, 'step6_title', 'Listing Activated'),
(703, 95, '_step6_title', 'field_5a42e5ca7f092'),
(704, 95, 'step6_text', 'Thank you for adding your property to Zaivia'),
(705, 95, '_step6_text', 'field_5a42e5f47f093'),
(706, 95, 'step6_button', 'Back To My Zaivia'),
(707, 95, '_step6_button', 'field_5a42e6077f094'),
(708, 236, '_edit_last', '1'),
(709, 236, '_edit_lock', '1514464314:1'),
(710, 236, '_wp_page_template', 'page-templates/home.php'),
(711, 236, 'search_title', 'Make Yourself at Home!'),
(712, 236, '_search_title', 'field_5a19e1b068ba4'),
(713, 236, 'search_text', 'Search for properties for sale or rent in Canada'),
(714, 236, '_search_text', 'field_5a19e1dc68ba5'),
(715, 236, 'intro_title', 'Quick. Easy. Professional.'),
(716, 236, '_intro_title', 'field_5a19e4ef4d694'),
(717, 236, 'intro_text', 'Zaivia connects Canadian home owners, buyers, renters, and sellers as well as the qualified, local professionals who support them. Zaivia is a quick, easy, professional and cost-effective solution – providing an abundance of features and services, most of which are absolutely <strong>FREE!</strong>'),
(718, 236, '_intro_text', 'field_5a19e5184d695'),
(719, 236, 'options', '4'),
(720, 236, '_options', 'field_5a1a00424cc1f'),
(721, 236, 'banner_title', 'Wanna Win $1000'),
(722, 236, '_banner_title', 'field_5a1a07c321542'),
(723, 236, 'banner_subtitle', 'Enter for FREE either by'),
(724, 236, '_banner_subtitle', 'field_5a1a07e221543'),
(725, 236, 'banner_options', '2'),
(726, 236, '_banner_options', 'field_5a1a07eb21544'),
(727, 237, 'search_title', 'Make Yourself at Home!'),
(728, 237, '_search_title', 'field_5a19e1b068ba4'),
(729, 237, 'search_text', 'Search for properties for sale or rent in Canada'),
(730, 237, '_search_text', 'field_5a19e1dc68ba5'),
(731, 237, 'intro_title', 'Quick. Easy. Professional.'),
(732, 237, '_intro_title', 'field_5a19e4ef4d694'),
(733, 237, 'intro_text', ''),
(734, 237, '_intro_text', 'field_5a19e5184d695'),
(735, 237, 'options', ''),
(736, 237, '_options', 'field_5a1a00424cc1f'),
(737, 237, 'banner_title', ''),
(738, 237, '_banner_title', 'field_5a1a07c321542'),
(739, 237, 'banner_subtitle', ''),
(740, 237, '_banner_subtitle', 'field_5a1a07e221543'),
(741, 237, 'banner_options', ''),
(742, 237, '_banner_options', 'field_5a1a07eb21544'),
(749, 236, 'options_0_image', '56'),
(750, 236, '_options_0_image', 'field_5a1a00504cc20'),
(751, 236, 'options_0_title', 'List For Free'),
(752, 236, '_options_0_title', 'field_5a1a014c4cc21'),
(753, 236, 'options_0_text', 'Do you have a property for sale or for rent? You can list it on Zaivia for absolutlely <strong>FREE!</strong>'),
(754, 236, '_options_0_text', 'field_5a1a01534cc22'),
(755, 236, 'options_0_button_url', '94'),
(756, 236, '_options_0_button_url', 'field_5a1a01a44cc23'),
(757, 236, 'options_1_image', '57'),
(758, 236, '_options_1_image', 'field_5a1a00504cc20'),
(759, 236, 'options_1_title', 'Agents Love Zaivia'),
(760, 236, '_options_1_title', 'field_5a1a014c4cc21'),
(761, 236, 'options_1_text', 'Zaivia has been developed with agents in mind. Market your properties for <strong>FREE!</strong>'),
(762, 236, '_options_1_text', 'field_5a1a01534cc22'),
(763, 236, 'options_1_button_url', '11'),
(764, 236, '_options_1_button_url', 'field_5a1a01a44cc23'),
(765, 236, 'options_2_image', '58'),
(766, 236, '_options_2_image', 'field_5a1a00504cc20'),
(767, 236, 'options_2_title', 'Find The Right Professional'),
(768, 236, '_options_2_title', 'field_5a1a014c4cc21'),
(769, 236, 'options_2_text', 'Do you need help with your property? Check out all our Community Partners!'),
(770, 236, '_options_2_text', 'field_5a1a01534cc22'),
(771, 236, 'options_2_button_url', '9'),
(772, 236, '_options_2_button_url', 'field_5a1a01a44cc23'),
(773, 236, 'options_3_image', '59'),
(774, 236, '_options_3_image', 'field_5a1a00504cc20'),
(775, 236, 'options_3_title', 'Promote Your Business'),
(776, 236, '_options_3_title', 'field_5a1a014c4cc21'),
(777, 236, 'options_3_text', 'What service does your business provide? Why not promote your business on Zaivia for <strong>FREE!</strong>'),
(778, 236, '_options_3_text', 'field_5a1a01534cc22'),
(779, 236, 'options_3_button_url', '82'),
(780, 236, '_options_3_button_url', 'field_5a1a01a44cc23'),
(781, 236, 'banner_options_0_text', 'like, share & comment on Facebook or'),
(782, 236, '_banner_options_0_text', 'field_5a1a07fe21545'),
(783, 236, 'banner_options_1_text', 'get a free entry for every property that you list on Zaivia'),
(784, 236, '_banner_options_1_text', 'field_5a1a07fe21545'),
(785, 241, 'search_title', 'Make Yourself at Home!'),
(786, 241, '_search_title', 'field_5a19e1b068ba4'),
(787, 241, 'search_text', 'Search for properties for sale or rent in Canada'),
(788, 241, '_search_text', 'field_5a19e1dc68ba5'),
(789, 241, 'intro_title', 'Quick. Easy. Professional.'),
(790, 241, '_intro_title', 'field_5a19e4ef4d694'),
(791, 241, 'intro_text', 'Zaivia connects Canadian home owners, buyers, renters, and sellers as well as the qualified, local professionals who support them. Zaivia is a quick, easy, professional and cost-effective solution – providing an abundance of features and services, most of which are absolutely <strong>FREE!</strong>'),
(792, 241, '_intro_text', 'field_5a19e5184d695'),
(793, 241, 'options', '4'),
(794, 241, '_options', 'field_5a1a00424cc1f'),
(795, 241, 'banner_title', 'Wanna Win $1000'),
(796, 241, '_banner_title', 'field_5a1a07c321542'),
(797, 241, 'banner_subtitle', 'Enter for FREE either by'),
(798, 241, '_banner_subtitle', 'field_5a1a07e221543'),
(799, 241, 'banner_options', '2'),
(800, 241, '_banner_options', 'field_5a1a07eb21544'),
(801, 241, 'options_0_image', '56'),
(802, 241, '_options_0_image', 'field_5a1a00504cc20'),
(803, 241, 'options_0_title', 'List For Free'),
(804, 241, '_options_0_title', 'field_5a1a014c4cc21'),
(805, 241, 'options_0_text', 'Do you have a property for sale or for rent? You can list it on Zaivia for absolutlely <strong>FREE!</strong>'),
(806, 241, '_options_0_text', 'field_5a1a01534cc22'),
(807, 241, 'options_0_button_url', '94'),
(808, 241, '_options_0_button_url', 'field_5a1a01a44cc23'),
(809, 241, 'options_1_image', '57'),
(810, 241, '_options_1_image', 'field_5a1a00504cc20'),
(811, 241, 'options_1_title', 'Agents Love Zaivia'),
(812, 241, '_options_1_title', 'field_5a1a014c4cc21'),
(813, 241, 'options_1_text', 'Zaivia has been developed with agents in mind. Market your properties for <strong>FREE!</strong>'),
(814, 241, '_options_1_text', 'field_5a1a01534cc22'),
(815, 241, 'options_1_button_url', '11'),
(816, 241, '_options_1_button_url', 'field_5a1a01a44cc23'),
(817, 241, 'options_2_image', '58'),
(818, 241, '_options_2_image', 'field_5a1a00504cc20'),
(819, 241, 'options_2_title', 'Find The Right Professional'),
(820, 241, '_options_2_title', 'field_5a1a014c4cc21'),
(821, 241, 'options_2_text', 'Do you need help with your property? Check out all our Community Partners!'),
(822, 241, '_options_2_text', 'field_5a1a01534cc22'),
(823, 241, 'options_2_button_url', '9'),
(824, 241, '_options_2_button_url', 'field_5a1a01a44cc23'),
(825, 241, 'options_3_image', '59'),
(826, 241, '_options_3_image', 'field_5a1a00504cc20'),
(827, 241, 'options_3_title', 'Promote Your Business'),
(828, 241, '_options_3_title', 'field_5a1a014c4cc21'),
(829, 241, 'options_3_text', 'What service does your business provide? Why not promote your business on Zaivia for <strong>FREE!</strong>'),
(830, 241, '_options_3_text', 'field_5a1a01534cc22'),
(831, 241, 'options_3_button_url', '82'),
(832, 241, '_options_3_button_url', 'field_5a1a01a44cc23'),
(833, 241, 'banner_options_0_text', 'like, share & comment on Facebook or'),
(834, 241, '_banner_options_0_text', 'field_5a1a07fe21545'),
(835, 241, 'banner_options_1_text', 'get a free entry for every property that you list on Zaivia'),
(836, 241, '_banner_options_1_text', 'field_5a1a07fe21545'),
(837, 242, '_edit_last', '1'),
(838, 242, '_edit_lock', '1517161694:1'),
(839, 242, '_wp_page_template', 'page-templates/rent.php'),
(858, 246, '_menu_item_type', 'post_type'),
(859, 246, '_menu_item_menu_item_parent', '0'),
(860, 246, '_menu_item_object_id', '242'),
(861, 246, '_menu_item_object', 'page'),
(862, 246, '_menu_item_target', ''),
(863, 246, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(864, 246, '_menu_item_xfn', ''),
(865, 246, '_menu_item_url', ''),
(867, 236, 'banner_text', 'Contest Rules'),
(868, 236, '_banner_text', 'field_5a44e456976d4'),
(869, 241, 'banner_text', 'Contest Rules'),
(870, 241, '_banner_text', 'field_5a44e456976d4'),
(880, 256, '_menu_item_type', 'post_type'),
(881, 256, '_menu_item_menu_item_parent', '0'),
(882, 256, '_menu_item_object_id', '80'),
(883, 256, '_menu_item_object', 'page'),
(884, 256, '_menu_item_target', ''),
(885, 256, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(886, 256, '_menu_item_xfn', ''),
(887, 256, '_menu_item_url', ''),
(889, 257, '_menu_item_type', 'post_type'),
(890, 257, '_menu_item_menu_item_parent', '0'),
(891, 257, '_menu_item_object_id', '77'),
(892, 257, '_menu_item_object', 'page'),
(893, 257, '_menu_item_target', ''),
(894, 257, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(895, 257, '_menu_item_xfn', ''),
(896, 257, '_menu_item_url', ''),
(898, 258, '_menu_item_type', 'post_type'),
(899, 258, '_menu_item_menu_item_parent', '0'),
(900, 258, '_menu_item_object_id', '82'),
(901, 258, '_menu_item_object', 'page'),
(902, 258, '_menu_item_target', ''),
(903, 258, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(904, 258, '_menu_item_xfn', ''),
(905, 258, '_menu_item_url', ''),
(906, 259, '_wp_attached_file', '2018/01/01-01_B1_3.jpg'),
(907, 259, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:22:\"2018/01/01-01_B1_3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:20:\"01-01_B1_3-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(908, 260, '_wp_attached_file', '2018/01/08-30_B_driving.png'),
(909, 260, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:27:\"2018/01/08-30_B_driving.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:25:\"08-30_B_driving-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(910, 261, '_wp_attached_file', '2018/01/01-01_B1_3-1.jpg'),
(911, 261, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-1-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-1-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-1-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(912, 262, '_wp_attached_file', '2018/01/08-30_B_driving-1.png'),
(913, 262, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-1.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-1-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(914, 263, '_wp_attached_file', '2018/01/08-30_B_driving-2.png'),
(915, 263, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-2.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-2-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(916, 264, '_wp_attached_file', '2018/01/01-01-003_I_DesignNam1.jpg'),
(917, 264, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:960;s:4:\"file\";s:34:\"2018/01/01-01-003_I_DesignNam1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignNam1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignNam1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignNam1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"01-01-003_I_DesignNam1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignNam1-285x214.jpg\";s:5:\"width\";i:285;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:33:\"01-01-003_I_DesignNam1-118x89.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:89;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(918, 265, '_wp_attached_file', '2018/01/01-01_B1_3-2.jpg'),
(919, 265, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-2-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-2-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-2-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(920, 266, '_wp_attached_file', '2018/01/08-30_B_driving-3.png'),
(921, 266, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-3.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-3-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(925, 268, '_wp_attached_file', '2018/01/01-01_B1_3-3.jpg'),
(926, 268, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-3.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-3-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-3-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-3-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(927, 269, '_wp_attached_file', '2018/01/08-28-12-14-CF_I2_DesignName.jpg'),
(928, 269, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:40:\"2018/01/08-28-12-14-CF_I2_DesignName.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"08-28-12-14-CF_I2_DesignName-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"08-28-12-14-CF_I2_DesignName-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"08-28-12-14-CF_I2_DesignName-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"08-28-12-14-CF_I2_DesignName-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:40:\"08-28-12-14-CF_I2_DesignName-321x181.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:181;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:39:\"08-28-12-14-CF_I2_DesignName-118x66.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:66;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(929, 270, '_wp_attached_file', '2018/01/01-01_B1_3-4.jpg'),
(930, 270, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-4.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-4-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-4-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-4-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-4-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(931, 271, '_wp_attached_file', '2018/01/08-30_B_driving-4.png'),
(932, 271, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-4.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-4-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(933, 272, '_wp_attached_file', '2018/01/08-30_B_driving-5.png'),
(934, 272, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-5.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-5-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(935, 273, '_wp_attached_file', '2018/01/01-01_B1_3-5.jpg'),
(936, 273, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-5.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-5-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-5-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-5-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(937, 274, '_wp_attached_file', '2018/01/DB_doc.docx'),
(938, 275, '_wp_attached_file', '2018/01/01-01-003_I_DesignNam1-1.jpg'),
(939, 275, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:960;s:4:\"file\";s:36:\"2018/01/01-01-003_I_DesignNam1-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"01-01-003_I_DesignNam1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"01-01-003_I_DesignNam1-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:36:\"01-01-003_I_DesignNam1-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"01-01-003_I_DesignNam1-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:36:\"01-01-003_I_DesignNam1-1-285x214.jpg\";s:5:\"width\";i:285;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:35:\"01-01-003_I_DesignNam1-1-118x89.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:89;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(940, 276, '_wp_attached_file', '2018/01/Без-имени-1.png'),
(941, 276, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2480;s:6:\"height\";i:3508;s:4:\"file\";s:31:\"2018/01/Без-имени-1.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"Без-имени-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"Без-имени-1-212x300.png\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"Без-имени-1-768x1086.png\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"Без-имени-1-724x1024.png\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:31:\"Без-имени-1-151x214.png\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:29:\"Без-имени-1-65x92.png\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(942, 277, '_wp_attached_file', '2018/01/01-01-003_I_DesignName.jpg'),
(943, 277, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2560;s:6:\"height\";i:1600;s:4:\"file\";s:34:\"2018/01/01-01-003_I_DesignName.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignName-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignName-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignName-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"01-01-003_I_DesignName-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:34:\"01-01-003_I_DesignName-321x201.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:33:\"01-01-003_I_DesignName-118x74.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:74;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(944, 278, '_wp_attached_file', '2018/01/01-01_B1_3-6.jpg'),
(945, 278, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-6.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-6-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-6-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-6-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(946, 279, '_wp_attached_file', '2018/01/08-30_B_driving-6.png'),
(947, 279, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-6.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-6-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(948, 280, '_wp_attached_file', '2018/01/DB_doc-1.docx'),
(949, 281, '_wp_attached_file', '2018/01/08-30_B_driving-7.png'),
(950, 281, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-7.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-7-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(951, 282, '_wp_attached_file', '2018/01/01-01_B1_3-7.jpg'),
(952, 282, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-7.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-7-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-7-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-7-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(953, 283, '_wp_attached_file', '2018/01/Без-имени-1-1.png'),
(954, 283, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2480;s:6:\"height\";i:3508;s:4:\"file\";s:33:\"2018/01/Без-имени-1-1.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"Без-имени-1-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"Без-имени-1-1-212x300.png\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:34:\"Без-имени-1-1-768x1086.png\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"Без-имени-1-1-724x1024.png\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:33:\"Без-имени-1-1-151x214.png\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:31:\"Без-имени-1-1-65x92.png\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(955, 284, '_wp_attached_file', '2018/01/profile-1.jpg');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(956, 284, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2560;s:6:\"height\";i:1600;s:4:\"file\";s:21:\"2018/01/profile-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"profile-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"profile-1-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"profile-1-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"profile-1-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:21:\"profile-1-321x201.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:20:\"profile-1-118x74.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:74;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(957, 285, '_wp_attached_file', '2018/01/logo-1.jpg'),
(958, 285, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1080;s:4:\"file\";s:18:\"2018/01/logo-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"logo-1-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"logo-1-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"logo-1-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:18:\"logo-1-321x181.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:181;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:17:\"logo-1-118x66.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:66;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(959, 286, '_wp_attached_file', '2018/01/01-01_B1_3-8.jpg'),
(960, 286, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:24:\"2018/01/01-01_B1_3-8.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-8-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-8-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:24:\"01-01_B1_3-8-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-8-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(961, 287, '_wp_attached_file', '2018/01/08-30_B_driving-8.png'),
(962, 287, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/01/08-30_B_driving-8.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-8-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(963, 288, '_edit_last', '1'),
(964, 288, '_edit_lock', '1516272597:1'),
(965, 288, '_wp_page_template', 'page-templates/buy.php'),
(966, 290, '_menu_item_type', 'post_type'),
(967, 290, '_menu_item_menu_item_parent', '0'),
(968, 290, '_menu_item_object_id', '288'),
(969, 290, '_menu_item_object', 'page'),
(970, 290, '_menu_item_target', ''),
(971, 290, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(972, 290, '_menu_item_xfn', ''),
(973, 290, '_menu_item_url', ''),
(985, 299, '_wp_attached_file', '2018/01/photo.jpg'),
(986, 299, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:350;s:6:\"height\";i:350;s:4:\"file\";s:17:\"2018/01/photo.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"photo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"photo-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:17:\"photo-214x214.jpg\";s:5:\"width\";i:214;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:15:\"photo-92x92.jpg\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(987, 300, '_wp_attached_file', '2018/01/ea-skynet-logo-200x200-9272-1.png'),
(988, 300, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:41:\"2018/01/ea-skynet-logo-200x200-9272-1.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"ea-skynet-logo-200x200-9272-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:39:\"ea-skynet-logo-200x200-9272-1-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(989, 301, '_wp_attached_file', '2018/01/john.jpg'),
(990, 301, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:640;s:6:\"height\";i:479;s:4:\"file\";s:16:\"2018/01/john.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"john-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"john-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:16:\"john-286x214.jpg\";s:5:\"width\";i:286;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:15:\"john-118x88.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:88;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(991, 302, '_wp_attached_file', '2018/01/ea-skynet-logo-200x200-9272-2.png'),
(992, 302, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:41:\"2018/01/ea-skynet-logo-200x200-9272-2.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:41:\"ea-skynet-logo-200x200-9272-2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:39:\"ea-skynet-logo-200x200-9272-2-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(993, 303, '_wp_attached_file', '2018/01/Pasquia_Gate.jpg'),
(994, 303, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:4:\"file\";s:24:\"2018/01/Pasquia_Gate.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"Pasquia_Gate-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"Pasquia_Gate-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:23:\"Pasquia_Gate-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"5.6\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"NIKON D40X\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1252577023\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"35\";s:3:\"iso\";s:3:\"110\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:1:{i:0;s:16:\"September 8 2009\";}}}'),
(995, 304, '_wp_attached_file', '2018/01/IMG_9419_20_21_tonemapped.jpg'),
(996, 304, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4267;s:6:\"height\";i:2837;s:4:\"file\";s:37:\"2018/01/IMG_9419_20_21_tonemapped.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"IMG_9419_20_21_tonemapped-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"IMG_9419_20_21_tonemapped-300x199.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"IMG_9419_20_21_tonemapped-768x511.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:511;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"IMG_9419_20_21_tonemapped-1024x681.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:681;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:37:\"IMG_9419_20_21_tonemapped-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:36:\"IMG_9419_20_21_tonemapped-118x78.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:78;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"11\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1430306918\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"18\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:5:\"0.002\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(997, 305, '_edit_last', '1'),
(998, 305, '_edit_lock', '1517313485:1'),
(999, 308, '_wp_attached_file', '2018/01/b1.jpg'),
(1000, 308, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:870;s:6:\"height\";i:127;s:4:\"file\";s:14:\"2018/01/b1.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"b1-150x127.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:127;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:13:\"b1-300x44.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:44;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:14:\"b1-768x112.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:112;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:13:\"b1-321x47.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:47;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:13:\"b1-118x17.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:17;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1001, 309, '_wp_attached_file', '2018/01/b2.jpg'),
(1002, 309, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:330;s:6:\"height\";i:270;s:4:\"file\";s:14:\"2018/01/b2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"b2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:14:\"b2-300x245.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:245;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:14:\"b2-262x214.jpg\";s:5:\"width\";i:262;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:13:\"b2-112x92.jpg\";s:5:\"width\";i:112;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1003, 288, 'list_banner_image', '308'),
(1004, 288, '_list_banner_image', 'field_5a5db8d8af3e3'),
(1005, 288, 'list_banner_url', 'https://google.com'),
(1006, 288, '_list_banner_url', 'field_5a5db96caf3e4'),
(1007, 310, 'list_banner_image', '308'),
(1008, 310, '_list_banner_image', 'field_5a5db8d8af3e3'),
(1009, 310, 'list_banner_url', 'https://google.com'),
(1010, 310, '_list_banner_url', 'field_5a5db96caf3e4'),
(1011, 313, '_wp_attached_file', '2018/01/b2-1.jpg'),
(1012, 313, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:330;s:6:\"height\";i:270;s:4:\"file\";s:16:\"2018/01/b2-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"b2-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"b2-1-300x245.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:245;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:16:\"b2-1-262x214.jpg\";s:5:\"width\";i:262;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:15:\"b2-1-112x92.jpg\";s:5:\"width\";i:112;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1013, 288, 'sidebar_banner_image', '313'),
(1014, 288, '_sidebar_banner_image', 'field_5a5dca7125533'),
(1015, 288, 'sidebar_banner_url', 'http://lib.ru'),
(1016, 288, '_sidebar_banner_url', 'field_5a5dcafd25534'),
(1017, 314, 'list_banner_image', '308'),
(1018, 314, '_list_banner_image', 'field_5a5db8d8af3e3'),
(1019, 314, 'list_banner_url', 'https://google.com'),
(1020, 314, '_list_banner_url', 'field_5a5db96caf3e4'),
(1021, 314, 'sidebar_banner_image', '313'),
(1022, 314, '_sidebar_banner_image', 'field_5a5dca7125533'),
(1023, 314, 'sidebar_banner_url', 'http://lib.ru'),
(1024, 314, '_sidebar_banner_url', 'field_5a5dcafd25534'),
(1025, 315, '_edit_last', '1'),
(1026, 315, '_wp_page_template', 'page-templates/listing.php'),
(1027, 315, '_edit_lock', '1517316721:1'),
(1028, 317, '_wp_attached_file', '2018/01/fl1.jpg'),
(1029, 317, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:537;s:6:\"height\";i:587;s:4:\"file\";s:15:\"2018/01/fl1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"fl1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"fl1-274x300.jpg\";s:5:\"width\";i:274;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:15:\"fl1-196x214.jpg\";s:5:\"width\";i:196;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:13:\"fl1-84x92.jpg\";s:5:\"width\";i:84;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1030, 318, '_wp_attached_file', '2018/01/IMG_9437.jpg'),
(1031, 318, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4272;s:6:\"height\";i:2848;s:4:\"file\";s:20:\"2018/01/IMG_9437.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"IMG_9437-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"IMG_9437-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"IMG_9437-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"IMG_9437-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:20:\"IMG_9437-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:19:\"IMG_9437-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264499\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:9:\"0.0015625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1032, 320, '_wp_attached_file', '2018/01/IMG_9435.jpg'),
(1033, 319, '_wp_attached_file', '2018/01/IMG_9436.jpg'),
(1034, 321, '_wp_attached_file', '2018/01/IMG_9436_7_8_tonemapped.jpg'),
(1035, 320, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4272;s:6:\"height\";i:2848;s:4:\"file\";s:20:\"2018/01/IMG_9435.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"IMG_9435-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"IMG_9435-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"IMG_9435-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"IMG_9435-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:20:\"IMG_9435-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:19:\"IMG_9435-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264434\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"28\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:5:\"0.025\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1036, 319, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4272;s:6:\"height\";i:2848;s:4:\"file\";s:20:\"2018/01/IMG_9436.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"IMG_9436-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"IMG_9436-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"IMG_9436-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"IMG_9436-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:20:\"IMG_9436-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:19:\"IMG_9436-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264499\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1037, 321, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4259;s:6:\"height\";i:2839;s:4:\"file\";s:35:\"2018/01/IMG_9436_7_8_tonemapped.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"IMG_9436_7_8_tonemapped-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"IMG_9436_7_8_tonemapped-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"IMG_9436_7_8_tonemapped-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:36:\"IMG_9436_7_8_tonemapped-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:35:\"IMG_9436_7_8_tonemapped-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:34:\"IMG_9436_7_8_tonemapped-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264499\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1038, 322, '_wp_attached_file', '2018/01/IMG_9428.jpg'),
(1039, 323, '_wp_attached_file', '2018/01/IMG_9427_8_9_tonemapped.jpg'),
(1040, 322, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4272;s:6:\"height\";i:2848;s:4:\"file\";s:20:\"2018/01/IMG_9428.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"IMG_9428-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"IMG_9428-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"IMG_9428-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"IMG_9428-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:20:\"IMG_9428-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:19:\"IMG_9428-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264217\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"28\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:9:\"0.0015625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1041, 323, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4255;s:6:\"height\";i:2837;s:4:\"file\";s:35:\"2018/01/IMG_9427_8_9_tonemapped.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"IMG_9427_8_9_tonemapped-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"IMG_9427_8_9_tonemapped-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"IMG_9427_8_9_tonemapped-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:36:\"IMG_9427_8_9_tonemapped-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:35:\"IMG_9427_8_9_tonemapped-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:34:\"IMG_9427_8_9_tonemapped-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264217\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"28\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1042, 324, '_wp_attached_file', '2018/01/IMG_9433.jpg'),
(1043, 325, '_wp_attached_file', '2018/01/IMG_9437-1.jpg'),
(1044, 324, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4272;s:6:\"height\";i:2848;s:4:\"file\";s:20:\"2018/01/IMG_9433.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"IMG_9433-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"IMG_9433-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"IMG_9433-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"IMG_9433-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:20:\"IMG_9433-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:19:\"IMG_9433-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264434\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"28\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1045, 325, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:4272;s:6:\"height\";i:2848;s:4:\"file\";s:22:\"2018/01/IMG_9437-1.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"IMG_9437-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"IMG_9437-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"IMG_9437-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"IMG_9437-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:22:\"IMG_9437-1-321x214.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:21:\"IMG_9437-1-118x79.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:79;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"Canon EOS 450D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1431264499\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"800\";s:13:\"shutter_speed\";s:9:\"0.0015625\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1046, 326, '_wp_attached_file', '2018/01/15-let-svadby-06.jpg'),
(1047, 327, '_wp_attached_file', '2018/01/0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2.jpg'),
(1048, 326, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:891;s:6:\"height\";i:637;s:4:\"file\";s:28:\"2018/01/15-let-svadby-06.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"15-let-svadby-06-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"15-let-svadby-06-300x214.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"15-let-svadby-06-768x549.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:549;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:28:\"15-let-svadby-06-299x214.jpg\";s:5:\"width\";i:299;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"15-let-svadby-06-118x84.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:84;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1049, 327, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:960;s:6:\"height\";i:1280;s:4:\"file\";s:91:\"2018/01/0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2.jpg\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:91:\"0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:91:\"0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2-225x300.jpg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:92:\"0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:92:\"0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2-768x1024.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:91:\"0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2-161x214.jpg\";s:5:\"width\";i:161;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:89:\"0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2-69x92.jpg\";s:5:\"width\";i:69;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1050, 328, '_edit_last', '1'),
(1051, 328, '_edit_lock', '1517311901:1'),
(1052, 328, '_wp_page_template', 'default'),
(1053, 340, '_menu_item_type', 'post_type'),
(1054, 340, '_menu_item_menu_item_parent', '0'),
(1055, 340, '_menu_item_object_id', '77'),
(1056, 340, '_menu_item_object', 'page'),
(1057, 340, '_menu_item_target', ''),
(1058, 340, '_menu_item_classes', 'a:2:{i:0;s:6:\"hidden\";i:1;s:13:\"login-visible\";}'),
(1059, 340, '_menu_item_xfn', ''),
(1060, 340, '_menu_item_url', ''),
(1061, 341, '_wp_attached_file', '2018/02/08-30_B1_Driving.jpg'),
(1062, 341, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:434;s:4:\"file\";s:28:\"2018/02/08-30_B1_Driving.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"08-30_B1_Driving-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"08-30_B1_Driving-300x217.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:217;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:28:\"08-30_B1_Driving-296x214.jpg\";s:5:\"width\";i:296;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B1_Driving-118x85.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"13\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:20:\"Canon EOS 5D Mark II\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:9:\"946716450\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"160\";s:13:\"shutter_speed\";s:17:\"0.076923076923077\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:1:{i:0;s:33:\"Photographer Pics 02.24.17 B1 RAW\";}}}'),
(1063, 342, '_wp_attached_file', '2018/02/08-30_B_driving.png'),
(1064, 342, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:27:\"2018/02/08-30_B_driving.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:25:\"08-30_B_driving-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1065, 343, '_wp_attached_file', '2018/02/Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15.jpg'),
(1066, 343, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2061;s:6:\"height\";i:2098;s:4:\"file\";s:73:\"2018/02/Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15.jpg\";s:5:\"sizes\";a:7:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:73:\"Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:73:\"Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15-295x300.jpg\";s:5:\"width\";i:295;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:73:\"Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15-768x782.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:782;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:75:\"Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15-1006x1024.jpg\";s:5:\"width\";i:1006;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"listing-big\";a:4:{s:4:\"file\";s:73:\"Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15-525x534.jpg\";s:5:\"width\";i:525;s:6:\"height\";i:534;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:73:\"Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15-210x214.jpg\";s:5:\"width\";i:210;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:71:\"Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15-90x92.jpg\";s:5:\"width\";i:90;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:155:\"The archetypal male face of beauty according to a new scientific study to mark the launch of the Samsung Galaxy S6.  Embargoed to 00.01hrs 30th March 2015.\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1067, 344, '_wp_attached_file', '2018/02/08-30_B_driving-1.png'),
(1068, 344, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/02/08-30_B_driving-1.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-1-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1069, 345, '_wp_attached_file', '2018/02/01-01_B1_3.jpg'),
(1070, 345, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:700;s:6:\"height\";i:990;s:4:\"file\";s:22:\"2018/02/01-01_B1_3.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"listing-big\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-378x534.jpg\";s:5:\"width\";i:378;s:6:\"height\";i:534;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:22:\"01-01_B1_3-151x214.jpg\";s:5:\"width\";i:151;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:20:\"01-01_B1_3-65x92.jpg\";s:5:\"width\";i:65;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1071, 346, '_wp_attached_file', '2018/02/08-30_B_driving-2.png'),
(1072, 346, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:92;s:6:\"height\";i:92;s:4:\"file\";s:29:\"2018/02/08-30_B_driving-2.png\";s:5:\"sizes\";a:1:{s:10:\"listing-th\";a:4:{s:4:\"file\";s:27:\"08-30_B_driving-2-92x92.png\";s:5:\"width\";i:92;s:6:\"height\";i:92;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1075, 349, '_wp_attached_file', '2018/02/66-01-E_Photo.jpg'),
(1076, 349, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:300;s:4:\"file\";s:25:\"2018/02/66-01-E_Photo.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"66-01-E_Photo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"66-01-E_Photo-300x180.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:25:\"66-01-E_Photo-321x193.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:193;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:24:\"66-01-E_Photo-118x71.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:71;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1078, 351, '_wp_attached_file', '2018/02/Магнитофон.docx'),
(1079, 352, '_wp_attached_file', '2018/02/50-11-006-HLF_Photo.jpg'),
(1080, 352, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:338;s:4:\"file\";s:31:\"2018/02/50-11-006-HLF_Photo.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"50-11-006-HLF_Photo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"50-11-006-HLF_Photo-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:31:\"50-11-006-HLF_Photo-321x181.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:181;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:30:\"50-11-006-HLF_Photo-118x66.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:66;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1085, 355, '_wp_attached_file', '2018/02/01-01.jpg'),
(1086, 355, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:439;s:6:\"height\";i:432;s:4:\"file\";s:17:\"2018/02/01-01.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"01-01-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"01-01-300x295.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:295;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:17:\"01-01-217x214.jpg\";s:5:\"width\";i:217;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:15:\"01-01-93x92.jpg\";s:5:\"width\";i:93;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:3:\"Web\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1087, 356, '_wp_attached_file', '2018/02/66-01-E_Photo-1.jpg'),
(1088, 356, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:300;s:4:\"file\";s:27:\"2018/02/66-01-E_Photo-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"66-01-E_Photo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"66-01-E_Photo-1-300x180.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:27:\"66-01-E_Photo-1-321x193.jpg\";s:5:\"width\";i:321;s:6:\"height\";i:193;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:26:\"66-01-E_Photo-1-118x71.jpg\";s:5:\"width\";i:118;s:6:\"height\";i:71;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(1089, 357, '_wp_attached_file', '2018/02/01-01-1.jpg'),
(1090, 357, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:439;s:6:\"height\";i:432;s:4:\"file\";s:19:\"2018/02/01-01-1.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"01-01-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"01-01-1-300x295.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:295;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"listing-card\";a:4:{s:4:\"file\";s:19:\"01-01-1-217x214.jpg\";s:5:\"width\";i:217;s:6:\"height\";i:214;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:10:\"listing-th\";a:4:{s:4:\"file\";s:17:\"01-01-1-93x92.jpg\";s:5:\"width\";i:93;s:6:\"height\";i:92;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:3:\"Web\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(1091, 358, '_edit_lock', '1519640150:1');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(9, 1, '2017-11-24 11:36:58', '2017-11-24 11:36:58', '', 'Find Agent', '', 'publish', 'closed', 'closed', '', 'find-agent', '', '', '2017-11-24 11:36:58', '2017-11-24 11:36:58', '', 0, 'http://localhost/zaivia/?page_id=9', 0, 'page', '', 0),
(10, 1, '2017-11-24 11:36:58', '2017-11-24 11:36:58', '', 'Find Agent', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-11-24 11:36:58', '2017-11-24 11:36:58', '', 9, 'http://localhost/zaivia/2017/11/24/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2017-11-24 11:37:05', '2017-11-24 11:37:05', '', 'Community Partners', '', 'publish', 'closed', 'closed', '', 'community-partners', '', '', '2017-11-24 11:37:05', '2017-11-24 11:37:05', '', 0, 'http://localhost/zaivia/?page_id=11', 0, 'page', '', 0),
(12, 1, '2017-11-24 11:37:05', '2017-11-24 11:37:05', '', 'Community Partners', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2017-11-24 11:37:05', '2017-11-24 11:37:05', '', 11, 'http://localhost/zaivia/2017/11/24/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-11-24 11:38:57', '2017-11-24 11:38:57', '', 'Resources', '', 'publish', 'closed', 'closed', '', 'resources', '', '', '2017-11-24 11:38:57', '2017-11-24 11:38:57', '', 0, 'http://localhost/zaivia/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-11-24 11:38:54', '2017-11-24 11:38:54', ' ', '', '', 'publish', 'closed', 'closed', '', '14', '', '', '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 0, 'http://localhost/zaivia/?p=14', 4, 'nav_menu_item', '', 0),
(15, 1, '2017-11-24 11:38:54', '2017-11-24 11:38:54', ' ', '', '', 'publish', 'closed', 'closed', '', '15', '', '', '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 0, 'http://localhost/zaivia/?p=15', 3, 'nav_menu_item', '', 0),
(18, 1, '2017-11-24 11:38:57', '2017-11-24 11:38:57', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-11-24 11:38:57', '2017-11-24 11:38:57', '', 13, 'http://localhost/zaivia/2017/11/24/13-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-11-24 11:39:35', '2017-11-24 11:39:35', ' ', '', '', 'publish', 'closed', 'closed', '', '19', '', '', '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 0, 'http://localhost/zaivia/?p=19', 5, 'nav_menu_item', '', 0),
(20, 1, '2017-11-24 11:39:35', '2017-11-24 11:39:35', '', 'Log In', '', 'publish', 'closed', 'closed', '', 'log-in', '', '', '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 0, 'http://localhost/zaivia/?p=20', 6, 'nav_menu_item', '', 0),
(24, 1, '2017-11-24 11:54:10', '2017-11-24 11:54:10', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2017-11-24 11:54:10', '2017-11-24 11:54:10', '', 0, 'http://localhost/zaivia/?p=24', 4, 'nav_menu_item', '', 0),
(25, 1, '2017-11-24 11:54:10', '2017-11-24 11:54:10', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2017-11-24 11:54:10', '2017-11-24 11:54:10', '', 0, 'http://localhost/zaivia/?p=25', 5, 'nav_menu_item', '', 0),
(26, 1, '2017-11-24 11:54:44', '2017-11-24 11:54:44', '', 'Terms of Use', '', 'publish', 'closed', 'closed', '', 'terms-of-use', '', '', '2017-11-24 11:54:44', '2017-11-24 11:54:44', '', 0, 'http://localhost/zaivia/?page_id=26', 0, 'page', '', 0),
(27, 1, '2017-11-24 11:54:44', '2017-11-24 11:54:44', '', 'Terms of Use', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2017-11-24 11:54:44', '2017-11-24 11:54:44', '', 26, 'http://localhost/zaivia/2017/11/24/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2017-11-24 11:54:50', '2017-11-24 11:54:50', '', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2017-11-24 11:54:50', '2017-11-24 11:54:50', '', 0, 'http://localhost/zaivia/?page_id=28', 0, 'page', '', 0),
(29, 1, '2017-11-24 11:54:50', '2017-11-24 11:54:50', '', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2017-11-24 11:54:50', '2017-11-24 11:54:50', '', 28, 'http://localhost/zaivia/2017/11/24/28-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2017-11-24 11:54:56', '2017-11-24 11:54:56', '', 'Posting Policy', '', 'publish', 'closed', 'closed', '', 'posting-policy', '', '', '2017-11-24 11:54:56', '2017-11-24 11:54:56', '', 0, 'http://localhost/zaivia/?page_id=30', 0, 'page', '', 0),
(31, 1, '2017-11-24 11:54:56', '2017-11-24 11:54:56', '', 'Posting Policy', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2017-11-24 11:54:56', '2017-11-24 11:54:56', '', 30, 'http://localhost/zaivia/2017/11/24/30-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2017-11-24 11:55:04', '2017-11-24 11:55:04', '', 'Refund Policy', '', 'publish', 'closed', 'closed', '', 'refund-policy', '', '', '2017-11-24 11:55:04', '2017-11-24 11:55:04', '', 0, 'http://localhost/zaivia/?page_id=32', 0, 'page', '', 0),
(33, 1, '2017-11-24 11:55:04', '2017-11-24 11:55:04', '', 'Refund Policy', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2017-11-24 11:55:04', '2017-11-24 11:55:04', '', 32, 'http://localhost/zaivia/2017/11/24/32-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2017-11-24 11:55:36', '2017-11-24 11:55:36', ' ', '', '', 'publish', 'closed', 'closed', '', '34', '', '', '2017-11-24 11:55:36', '2017-11-24 11:55:36', '', 0, 'http://localhost/zaivia/?p=34', 1, 'nav_menu_item', '', 0),
(35, 1, '2017-11-24 11:55:36', '2017-11-24 11:55:36', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2017-11-24 11:55:36', '2017-11-24 11:55:36', '', 0, 'http://localhost/zaivia/?p=35', 2, 'nav_menu_item', '', 0),
(36, 1, '2017-11-24 11:55:36', '2017-11-24 11:55:36', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2017-11-24 11:55:36', '2017-11-24 11:55:36', '', 0, 'http://localhost/zaivia/?p=36', 3, 'nav_menu_item', '', 0),
(37, 1, '2017-11-24 11:55:36', '2017-11-24 11:55:36', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2017-11-24 11:55:36', '2017-11-24 11:55:36', '', 0, 'http://localhost/zaivia/?p=37', 4, 'nav_menu_item', '', 0),
(38, 1, '2017-11-24 11:58:31', '2017-11-24 11:58:31', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:22:\"theme-general-settings\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Settings', 'settings', 'publish', 'closed', 'closed', '', 'group_5a180954e376f', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 0, 'http://localhost/zaivia/?post_type=acf-field-group&#038;p=38', 0, 'acf-field-group', '', 0),
(39, 1, '2017-11-24 11:59:42', '2017-11-24 11:59:42', 'a:11:{s:4:\"type\";s:8:\"textarea\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Footer text', 'footer_text', 'publish', 'closed', 'closed', '', 'field_5a18098ba1155', '', '', '2017-12-03 21:44:28', '2017-12-03 21:44:28', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=39', 1, 'acf-field', '', 0),
(40, 1, '2017-11-24 12:01:04', '2017-11-24 12:01:04', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Facebook', 'facebook', 'publish', 'closed', 'closed', '', 'field_5a1809e7b28ce', '', '', '2017-12-03 21:44:28', '2017-12-03 21:44:28', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=40', 2, 'acf-field', '', 0),
(41, 1, '2017-11-24 12:01:04', '2017-11-24 12:01:04', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Twitter', 'twitter', 'publish', 'closed', 'closed', '', 'field_5a1809fdb28cf', '', '', '2017-12-03 21:44:28', '2017-12-03 21:44:28', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=41', 3, 'acf-field', '', 0),
(43, 1, '2017-11-25 21:35:25', '2017-11-25 21:35:25', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:23:\"page-templates/home.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Homepage', 'homepage', 'publish', 'closed', 'closed', '', 'group_5a19e193d0a03', '', '', '2018-02-26 10:17:06', '2018-02-26 10:17:06', '', 0, 'http://localhost/zaivia/?post_type=acf-field-group&#038;p=43', 0, 'acf-field-group', '', 0),
(48, 1, '2017-11-25 21:48:51', '2017-11-25 21:48:51', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:26:\"Quick. Easy. Professional.\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Intro Title', 'intro_title', 'publish', 'closed', 'closed', '', 'field_5a19e4ef4d694', '', '', '2018-02-26 10:17:05', '2018-02-26 10:17:05', '', 43, 'http://localhost/zaivia/?post_type=acf-field&#038;p=48', 0, 'acf-field', '', 0),
(49, 1, '2017-11-25 21:48:51', '2017-11-25 21:48:51', 'a:11:{s:4:\"type\";s:8:\"textarea\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Intro Text', 'intro_text', 'publish', 'closed', 'closed', '', 'field_5a19e5184d695', '', '', '2018-02-26 10:17:05', '2018-02-26 10:17:05', '', 43, 'http://localhost/zaivia/?post_type=acf-field&#038;p=49', 1, 'acf-field', '', 0),
(50, 1, '2017-11-25 23:53:40', '2017-11-25 23:53:40', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Options', 'options', 'publish', 'closed', 'closed', '', 'field_5a1a00424cc1f', '', '', '2018-02-26 10:17:05', '2018-02-26 10:17:05', '', 43, 'http://localhost/zaivia/?post_type=acf-field&#038;p=50', 2, 'acf-field', '', 0),
(51, 1, '2017-11-25 23:53:40', '2017-11-25 23:53:40', 'a:16:{s:4:\"type\";s:5:\"image\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_5a1a00504cc20', '', '', '2017-11-26 00:14:29', '2017-11-26 00:14:29', '', 50, 'http://localhost/zaivia/?post_type=acf-field&#038;p=51', 0, 'acf-field', '', 0),
(52, 1, '2017-11-25 23:53:40', '2017-11-25 23:53:40', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_5a1a014c4cc21', '', '', '2017-11-25 23:53:40', '2017-11-25 23:53:40', '', 50, 'http://localhost/zaivia/?post_type=acf-field&p=52', 1, 'acf-field', '', 0),
(53, 1, '2017-11-25 23:53:40', '2017-11-25 23:53:40', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_5a1a01534cc22', '', '', '2017-11-25 23:53:40', '2017-11-25 23:53:40', '', 50, 'http://localhost/zaivia/?post_type=acf-field&p=53', 2, 'acf-field', '', 0),
(54, 1, '2017-11-25 23:53:40', '2017-11-25 23:53:40', 'a:11:{s:4:\"type\";s:9:\"page_link\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'Button Url', 'button_url', 'publish', 'closed', 'closed', '', 'field_5a1a01a44cc23', '', '', '2017-12-28 12:27:39', '2017-12-28 12:27:39', '', 50, 'http://localhost/zaivia/?post_type=acf-field&#038;p=54', 3, 'acf-field', '', 0),
(56, 1, '2017-11-26 00:09:55', '2017-11-26 00:09:55', '', 'h4', '', 'inherit', 'open', 'closed', '', 'h4', '', '', '2017-12-28 11:49:06', '2017-12-28 11:49:06', '', 236, 'http://localhost/zaivia/wp-content/uploads/2017/10/h4.png', 0, 'attachment', 'image/png', 0),
(57, 1, '2017-11-26 00:10:09', '2017-11-26 00:10:09', '', 'h5', '', 'inherit', 'open', 'closed', '', 'h5', '', '', '2017-12-28 11:49:06', '2017-12-28 11:49:06', '', 236, 'http://localhost/zaivia/wp-content/uploads/2017/10/h5.png', 0, 'attachment', 'image/png', 0),
(58, 1, '2017-11-26 00:10:21', '2017-11-26 00:10:21', '', 'h6', '', 'inherit', 'open', 'closed', '', 'h6', '', '', '2017-12-28 11:49:06', '2017-12-28 11:49:06', '', 236, 'http://localhost/zaivia/wp-content/uploads/2017/10/h6.png', 0, 'attachment', 'image/png', 0),
(59, 1, '2017-11-26 00:10:28', '2017-11-26 00:10:28', '', 'h7', '', 'inherit', 'open', 'closed', '', 'h7', '', '', '2017-12-28 11:49:06', '2017-12-28 11:49:06', '', 236, 'http://localhost/zaivia/wp-content/uploads/2017/10/h7.png', 0, 'attachment', 'image/png', 0),
(61, 1, '2017-11-26 00:17:13', '2017-11-26 00:17:13', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Banner Title', 'banner_title', 'publish', 'closed', 'closed', '', 'field_5a1a07c321542', '', '', '2018-02-26 10:17:05', '2018-02-26 10:17:05', '', 43, 'http://localhost/zaivia/?post_type=acf-field&#038;p=61', 3, 'acf-field', '', 0),
(62, 1, '2017-11-26 00:17:13', '2017-11-26 00:17:13', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Banner Subtitle', 'banner_subtitle', 'publish', 'closed', 'closed', '', 'field_5a1a07e221543', '', '', '2018-02-26 10:17:05', '2018-02-26 10:17:05', '', 43, 'http://localhost/zaivia/?post_type=acf-field&#038;p=62', 4, 'acf-field', '', 0),
(63, 1, '2017-11-26 00:17:13', '2017-11-26 00:17:13', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Banner Options', 'banner_options', 'publish', 'closed', 'closed', '', 'field_5a1a07eb21544', '', '', '2018-02-26 10:17:05', '2018-02-26 10:17:05', '', 43, 'http://localhost/zaivia/?post_type=acf-field&#038;p=63', 5, 'acf-field', '', 0),
(64, 1, '2017-11-26 00:17:13', '2017-11-26 00:17:13', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Text', 'text', 'publish', 'closed', 'closed', '', 'field_5a1a07fe21545', '', '', '2017-11-26 00:17:13', '2017-11-26 00:17:13', '', 63, 'http://localhost/zaivia/?post_type=acf-field&p=64', 0, 'acf-field', '', 0),
(68, 1, '2017-12-02 23:47:55', '2017-12-02 23:47:55', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Google API Key', 'google_api_key', 'publish', 'closed', 'closed', '', 'field_5a233ba171c65', '', '', '2017-12-03 21:44:28', '2017-12-03 21:44:28', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=68', 4, 'acf-field', '', 0),
(69, 1, '2017-12-03 21:43:28', '2017-12-03 21:43:28', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Listing', '', 'publish', 'closed', 'closed', '', 'field_5a246ff6b2aa2', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=69', 7, 'acf-field', '', 0),
(70, 1, '2017-12-03 21:43:51', '2017-12-03 21:43:51', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Property Type', 'property_type', 'publish', 'closed', 'closed', '', 'field_5a24700239411', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=70', 8, 'acf-field', '', 0),
(71, 1, '2017-12-03 21:43:51', '2017-12-03 21:43:51', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a24700b39412', '', '', '2017-12-03 21:43:51', '2017-12-03 21:43:51', '', 70, 'http://localhost/zaivia/?post_type=acf-field&p=71', 0, 'acf-field', '', 0),
(72, 1, '2017-12-03 21:44:28', '2017-12-03 21:44:28', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Common', '', 'publish', 'closed', 'closed', '', 'field_5a247030fe8dc', '', '', '2017-12-03 21:44:28', '2017-12-03 21:44:28', '', 38, 'http://localhost/zaivia/?post_type=acf-field&p=72', 0, 'acf-field', '', 0),
(73, 1, '2017-12-03 21:52:12', '2017-12-03 21:52:12', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Bedrooms', 'bedrooms', 'publish', 'closed', 'closed', '', 'field_5a2471e969ac8', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=73', 14, 'acf-field', '', 0),
(74, 1, '2017-12-03 21:52:12', '2017-12-03 21:52:12', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2471e969ac9', '', '', '2017-12-03 21:52:12', '2017-12-03 21:52:12', '', 73, 'http://localhost/zaivia/?post_type=acf-field&p=74', 0, 'acf-field', '', 0),
(75, 1, '2017-12-03 21:52:12', '2017-12-03 21:52:12', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Bathrooms', 'bathrooms', 'publish', 'closed', 'closed', '', 'field_5a2471f469aca', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=75', 15, 'acf-field', '', 0),
(76, 1, '2017-12-03 21:52:12', '2017-12-03 21:52:12', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2471f469acb', '', '', '2017-12-03 21:52:12', '2017-12-03 21:52:12', '', 75, 'http://localhost/zaivia/?post_type=acf-field&p=76', 0, 'acf-field', '', 0),
(77, 1, '2017-12-04 06:27:29', '2017-12-04 06:27:29', 'Post a listing is easy - just follow the steps. You can always save your work and complete your listing at your convenience', 'My Listings', '', 'publish', 'closed', 'closed', '', 'my-listings', '', '', '2017-12-10 10:10:31', '2017-12-10 10:10:31', '', 0, 'http://localhost/zaivia/?page_id=77', 0, 'page', '', 0),
(78, 1, '2017-12-04 06:27:29', '2017-12-04 06:27:29', 'Post a listing is easy - just follow the steps. You can always save your work and complete your listing at your convenience', 'My Listings', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-12-04 06:27:29', '2017-12-04 06:27:29', '', 77, 'http://localhost/zaivia/2017/12/04/77-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2017-12-04 06:35:47', '2017-12-04 06:35:47', '', 'My Profile', '', 'publish', 'closed', 'closed', '', 'my-profile', '', '', '2018-02-22 12:04:09', '2018-02-22 12:04:09', '', 0, 'http://localhost/zaivia/?page_id=80', 0, 'page', '', 0),
(81, 1, '2017-12-04 06:35:47', '2017-12-04 06:35:47', '', 'My Zaivia', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2017-12-04 06:35:47', '2017-12-04 06:35:47', '', 80, 'http://localhost/zaivia/2017/12/04/80-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2017-12-04 06:36:12', '2017-12-04 06:36:12', '', 'Promote My Business', '', 'publish', 'closed', 'closed', '', 'promote-my-business', '', '', '2017-12-04 06:36:12', '2017-12-04 06:36:12', '', 0, 'http://localhost/zaivia/?page_id=82', 0, 'page', '', 0),
(83, 1, '2017-12-04 06:36:12', '2017-12-04 06:36:12', '', 'Promote My Business', '', 'inherit', 'closed', 'closed', '', '82-revision-v1', '', '', '2017-12-04 06:36:12', '2017-12-04 06:36:12', '', 82, 'http://localhost/zaivia/2017/12/04/82-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2017-12-04 06:50:37', '2017-12-04 06:50:37', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:30:\"page-templates/my-listings.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'My Listings', 'my-listings', 'publish', 'closed', 'closed', '', 'group_5a24f0184430c', '', '', '2017-12-04 06:52:50', '2017-12-04 06:52:50', '', 0, 'http://localhost/zaivia/?post_type=acf-field-group&#038;p=87', 0, 'acf-field-group', '', 0),
(88, 1, '2017-12-04 06:50:37', '2017-12-04 06:50:37', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Button Title', 'button_title', 'publish', 'closed', 'closed', '', 'field_5a24f028cc4a3', '', '', '2017-12-04 06:50:37', '2017-12-04 06:50:37', '', 87, 'http://localhost/zaivia/?post_type=acf-field&p=88', 0, 'acf-field', '', 0),
(89, 1, '2017-12-04 06:50:54', '2017-12-04 06:50:54', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Button Text', 'button_text', 'publish', 'closed', 'closed', '', 'field_5a24f041531f6', '', '', '2017-12-04 06:50:54', '2017-12-04 06:50:54', '', 87, 'http://localhost/zaivia/?post_type=acf-field&p=89', 1, 'acf-field', '', 0),
(90, 1, '2017-12-04 06:51:41', '2017-12-04 06:51:41', 'Post a listing is easy - just follow the steps. You can always save your work and complete your listing at your convenience', 'My Listings', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-12-04 06:51:41', '2017-12-04 06:51:41', '', 77, 'http://localhost/zaivia/2017/12/04/77-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2017-12-04 06:52:50', '2017-12-04 06:52:50', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Table Title', 'table_title', 'publish', 'closed', 'closed', '', 'field_5a24f0bbb8159', '', '', '2017-12-04 06:52:50', '2017-12-04 06:52:50', '', 87, 'http://localhost/zaivia/?post_type=acf-field&p=91', 2, 'acf-field', '', 0),
(92, 1, '2017-12-04 06:53:07', '2017-12-04 06:53:07', 'Post a listing is easy - just follow the steps. You can always save your work and complete your listing at your convenience', 'My Listings', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-12-04 06:53:07', '2017-12-04 06:53:07', '', 77, 'http://localhost/zaivia/2017/12/04/77-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2017-12-04 07:28:55', '2017-12-04 07:28:55', 'Post a listing is easy - just follow the steps. You can always save your work and complete your listing at your convenience', 'My Listings', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-12-04 07:28:55', '2017-12-04 07:28:55', '', 77, 'http://localhost/zaivia/2017/12/04/77-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2017-12-04 07:30:02', '2017-12-04 07:30:02', '', 'Post Listing', '', 'publish', 'closed', 'closed', '', 'post-listing', '', '', '2017-12-27 00:15:40', '2017-12-27 00:15:40', '', 0, 'http://localhost/zaivia/?page_id=94', 0, 'page', '', 0),
(95, 1, '2017-12-04 07:30:02', '2017-12-04 07:30:02', '', 'Post Listing', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2017-12-04 07:30:02', '2017-12-04 07:30:02', '', 94, 'http://localhost/zaivia/2017/12/04/94-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2017-12-05 23:52:20', '2017-12-05 23:52:20', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Parking', 'parking', 'publish', 'closed', 'closed', '', 'field_5a273128be5b1', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=96', 12, 'acf-field', '', 0),
(97, 1, '2017-12-05 23:52:20', '2017-12-05 23:52:20', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a273128be5b2', '', '', '2017-12-05 23:52:20', '2017-12-05 23:52:20', '', 96, 'http://localhost/zaivia/?post_type=acf-field&p=97', 0, 'acf-field', '', 0),
(100, 1, '2017-12-06 00:02:42', '2017-12-06 00:02:42', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Roof Type', 'roof_type', 'publish', 'closed', 'closed', '', 'field_5a27339d34347', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=100', 10, 'acf-field', '', 0),
(101, 1, '2017-12-06 00:02:42', '2017-12-06 00:02:42', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a27339d34348', '', '', '2017-12-06 00:02:42', '2017-12-06 00:02:42', '', 100, 'http://localhost/zaivia/?post_type=acf-field&p=101', 0, 'acf-field', '', 0),
(104, 1, '2017-12-06 00:21:26', '2017-12-06 00:21:26', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Exterior Type', 'exterior_type', 'publish', 'closed', 'closed', '', 'field_5a2737fdb2e0a', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=104', 11, 'acf-field', '', 0),
(105, 1, '2017-12-06 00:21:26', '2017-12-06 00:21:26', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2737fdb2e0b', '', '', '2017-12-06 00:21:26', '2017-12-06 00:21:26', '', 104, 'http://localhost/zaivia/?post_type=acf-field&p=105', 0, 'acf-field', '', 0),
(106, 1, '2017-12-06 00:30:09', '2017-12-06 00:30:09', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Driveway', 'driveway', 'publish', 'closed', 'closed', '', 'field_5a273a094e154', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=106', 13, 'acf-field', '', 0),
(107, 1, '2017-12-06 00:30:09', '2017-12-06 00:30:09', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a273a094e155', '', '', '2017-12-06 00:30:09', '2017-12-06 00:30:09', '', 106, 'http://localhost/zaivia/?post_type=acf-field&p=107', 0, 'acf-field', '', 0),
(108, 1, '2017-12-06 00:32:48', '2017-12-06 00:32:48', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Size Units', 'size_units', 'publish', 'closed', 'closed', '', 'field_5a273a98bbe9f', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=108', 16, 'acf-field', '', 0),
(109, 1, '2017-12-06 00:32:48', '2017-12-06 00:32:48', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a273a98bbea0', '', '', '2017-12-06 00:32:48', '2017-12-06 00:32:48', '', 108, 'http://localhost/zaivia/?post_type=acf-field&p=109', 0, 'acf-field', '', 0),
(112, 1, '2017-12-07 23:31:52', '2017-12-07 23:31:52', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Partial Space for Rent', 'partial_rent', 'publish', 'closed', 'closed', '', 'field_5a29cf58713a0', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=112', 17, 'acf-field', '', 0),
(113, 1, '2017-12-07 23:31:52', '2017-12-07 23:31:52', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a29cf58713a1', '', '', '2017-12-07 23:31:52', '2017-12-07 23:31:52', '', 112, 'http://localhost/zaivia/?post_type=acf-field&p=113', 0, 'acf-field', '', 0),
(128, 1, '2017-12-09 19:59:53', '2017-12-09 19:59:53', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Room Features', 'room_features', 'publish', 'closed', 'closed', '', 'field_5a2c3e1b3cde9', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=128', 21, 'acf-field', '', 0),
(129, 1, '2017-12-09 19:59:53', '2017-12-09 19:59:53', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'room name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2c3e1b3cdea', '', '', '2017-12-09 19:59:53', '2017-12-09 19:59:53', '', 128, 'http://localhost/zaivia/?post_type=acf-field&p=129', 0, 'acf-field', '', 0),
(130, 1, '2017-12-09 19:59:53', '2017-12-09 19:59:53', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'key', 'key', 'publish', 'closed', 'closed', '', 'field_5a2c3e1b3cdeb', '', '', '2017-12-09 19:59:53', '2017-12-09 19:59:53', '', 128, 'http://localhost/zaivia/?post_type=acf-field&p=130', 1, 'acf-field', '', 0),
(131, 1, '2017-12-09 21:50:29', '2017-12-09 21:50:29', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Other Feartures', 'features_1', 'publish', 'closed', 'closed', '', 'field_5a2c5a72a5505', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=131', 18, 'acf-field', '', 0),
(132, 1, '2017-12-09 21:50:29', '2017-12-09 21:50:29', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2c5a72a5506', '', '', '2017-12-09 21:50:29', '2017-12-09 21:50:29', '', 131, 'http://localhost/zaivia/?post_type=acf-field&p=132', 0, 'acf-field', '', 0),
(133, 1, '2017-12-09 21:50:29', '2017-12-09 21:50:29', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Appliances Included', 'features_2', 'publish', 'closed', 'closed', '', 'field_5a2c5a88a5507', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=133', 19, 'acf-field', '', 0),
(134, 1, '2017-12-09 21:50:29', '2017-12-09 21:50:29', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2c5a88a5508', '', '', '2017-12-09 21:50:29', '2017-12-09 21:50:29', '', 133, 'http://localhost/zaivia/?post_type=acf-field&p=134', 0, 'acf-field', '', 0),
(135, 1, '2017-12-09 21:50:29', '2017-12-09 21:50:29', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Outdoor Amenities', 'features_3', 'publish', 'closed', 'closed', '', 'field_5a2c5a9ca5509', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=135', 20, 'acf-field', '', 0),
(136, 1, '2017-12-09 21:50:29', '2017-12-09 21:50:29', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2c5a9ca550a', '', '', '2017-12-09 21:50:29', '2017-12-09 21:50:29', '', 135, 'http://localhost/zaivia/?post_type=acf-field&p=136', 0, 'acf-field', '', 0),
(137, 1, '2017-12-10 10:10:31', '2017-12-10 10:10:31', 'Post a listing is easy - just follow the steps. You can always save your work and complete your listing at your convenience', 'My Listings', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2017-12-10 10:10:31', '2017-12-10 10:10:31', '', 77, 'http://localhost/zaivia/2017/12/10/77-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2017-12-10 16:02:43', '2017-12-10 16:02:43', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Type of House', 'house_type', 'publish', 'closed', 'closed', '', 'field_5a2d5a94790a1', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=139', 9, 'acf-field', '', 0),
(140, 1, '2017-12-10 16:02:43', '2017-12-10 16:02:43', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'name', 'name', 'publish', 'closed', 'closed', '', 'field_5a2d5a94790a2', '', '', '2017-12-10 16:02:43', '2017-12-10 16:02:43', '', 139, 'http://localhost/zaivia/?post_type=acf-field&p=140', 0, 'acf-field', '', 0),
(141, 1, '2017-12-13 12:25:17', '2017-12-13 12:25:17', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Rent Utilities', 'rent_utilities', 'publish', 'closed', 'closed', '', 'field_5a311b7d466cf', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=141', 22, 'acf-field', '', 0),
(142, 1, '2017-12-13 12:25:17', '2017-12-13 12:25:17', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Name', 'name', 'publish', 'closed', 'closed', '', 'field_5a311c07466d1', '', '', '2017-12-13 12:25:17', '2017-12-13 12:25:17', '', 141, 'http://localhost/zaivia/?post_type=acf-field&p=142', 0, 'acf-field', '', 0),
(143, 1, '2017-12-13 12:25:17', '2017-12-13 12:25:17', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Key', 'key', 'publish', 'closed', 'closed', '', 'field_5a311c15466d2', '', '', '2017-12-13 12:25:17', '2017-12-13 12:25:17', '', 141, 'http://localhost/zaivia/?post_type=acf-field&p=143', 1, 'acf-field', '', 0),
(144, 1, '2017-12-15 12:49:38', '2017-12-15 12:49:38', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:31:\"page-templates/post-listing.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Add/Edit Listing Page', 'add-edit-listing-page', 'publish', 'closed', 'closed', '', 'group_5a33c3543beca', '', '', '2017-12-27 00:15:20', '2017-12-27 00:15:20', '', 0, 'http://localhost/zaivia/?post_type=acf-field-group&#038;p=144', 0, 'acf-field-group', '', 0),
(145, 1, '2017-12-15 12:49:38', '2017-12-15 12:49:38', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Step 1', 'step_1', 'publish', 'closed', 'closed', '', 'field_5a33c403e092f', '', '', '2017-12-15 12:49:38', '2017-12-15 12:49:38', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=145', 0, 'acf-field', '', 0),
(146, 1, '2017-12-15 12:49:38', '2017-12-15 12:49:38', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:67:\"Would you like to start with one of your previously saved listings?\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Select Draft', 'select_draft', 'publish', 'closed', 'closed', '', 'field_5a33c41ae0930', '', '', '2017-12-15 12:49:38', '2017-12-15 12:49:38', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=146', 1, 'acf-field', '', 0),
(147, 1, '2017-12-15 12:49:38', '2017-12-15 12:49:38', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:37:\"Click on map to set property location\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Map Click', 'map_click', 'publish', 'closed', 'closed', '', 'field_5a33c487e0931', '', '', '2017-12-15 12:49:38', '2017-12-15 12:49:38', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=147', 2, 'acf-field', '', 0),
(148, 1, '2017-12-16 12:37:27', '2017-12-16 12:37:27', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Step 2', '', 'publish', 'closed', 'closed', '', 'field_5a351367e7d27', '', '', '2017-12-16 12:37:27', '2017-12-16 12:37:27', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=148', 3, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(149, 1, '2017-12-16 12:37:27', '2017-12-16 12:37:27', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:36:\"Click on all of the items that apply\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Click to Select', 'click_to_select', 'publish', 'closed', 'closed', '', 'field_5a351374e7d28', '', '', '2017-12-16 12:37:27', '2017-12-16 12:37:27', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=149', 4, 'acf-field', '', 0),
(150, 1, '2017-12-16 12:40:39', '2017-12-16 12:40:39', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:54:\"List up to three items for each of the following areas\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'List up to Three', 'list_up_to_three', 'publish', 'closed', 'closed', '', 'field_5a35142eccdfe', '', '', '2017-12-16 12:40:39', '2017-12-16 12:40:39', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=150', 5, 'acf-field', '', 0),
(151, 1, '2017-12-16 12:41:43', '2017-12-16 12:41:43', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:45:\"Provide a written description of the property\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Description', 'description', 'publish', 'closed', 'closed', '', 'field_5a3514799320d', '', '', '2017-12-16 12:41:43', '2017-12-16 12:41:43', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=151', 6, 'acf-field', '', 0),
(152, 1, '2017-12-16 12:43:00', '2017-12-16 12:43:00', 'a:11:{s:4:\"type\";s:8:\"textarea\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:180:\"Planning an Open House? Why not add this to your listing! If you are not sure of open dates now, you can always add them later through My Zaivia<br>\r\nProvide open house information\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Openhouse', 'openhouse', 'publish', 'closed', 'closed', '', 'field_5a3514a33b527', '', '', '2017-12-16 12:43:00', '2017-12-16 12:43:00', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=152', 7, 'acf-field', '', 0),
(153, 1, '2017-12-16 23:31:53', '2017-12-16 23:31:53', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:110:\"Note this contact information does not change any other contact information on other listings / contact cards.\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Contact Note', 'contact_note', 'publish', 'closed', 'closed', '', 'field_5a35acd9ae4a9', '', '', '2017-12-19 11:45:42', '2017-12-19 11:45:42', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=153', 14, 'acf-field', '', 0),
(154, 1, '2017-12-16 23:32:43', '2017-12-16 23:32:43', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Step 4', '', 'publish', 'closed', 'closed', '', 'field_5a35acf900dd3', '', '', '2017-12-19 11:36:44', '2017-12-19 11:36:44', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=154', 12, 'acf-field', '', 0),
(155, 1, '2017-12-16 23:32:43', '2017-12-16 23:32:43', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:105:\"Who can be contacted about this property? Please ensure the following information is correct and complete\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Who can be contacted', 'who_can_be_contacted', 'publish', 'closed', 'closed', '', 'field_5a35ad0600dd4', '', '', '2017-12-19 11:45:42', '2017-12-19 11:45:42', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=155', 13, 'acf-field', '', 0),
(189, 1, '2017-12-19 11:36:44', '2017-12-19 11:36:44', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Step 3', '', 'publish', 'closed', 'closed', '', 'field_5a38f94511ad9', '', '', '2017-12-19 11:36:44', '2017-12-19 11:36:44', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=189', 8, 'acf-field', '', 0),
(190, 1, '2017-12-19 11:36:44', '2017-12-19 11:36:44', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:254:\"Having high quality images as critical for generating interest in your property. Follow our photography tips to enhance your pictures, or check out our Community Partners page to hire a professional photographer. You can upload up to a maximum 30 images.\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Upload Title', 'upload_title', 'publish', 'closed', 'closed', '', 'field_5a38f96211ada', '', '', '2017-12-19 11:36:44', '2017-12-19 11:36:44', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=190', 9, 'acf-field', '', 0),
(191, 1, '2017-12-19 11:36:44', '2017-12-19 11:36:44', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:82:\"We encourage you to see an external picture of your property as the first picture.\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Image Title', 'image_title', 'publish', 'closed', 'closed', '', 'field_5a38f97811adb', '', '', '2017-12-19 11:36:44', '2017-12-19 11:36:44', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=191', 10, 'acf-field', '', 0),
(192, 1, '2017-12-19 11:36:44', '2017-12-19 11:36:44', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:26:\"Upload property blueprints\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Blueprint Title', 'blueprint_title', 'publish', 'closed', 'closed', '', 'field_5a38f98711adc', '', '', '2017-12-19 11:36:44', '2017-12-19 11:36:44', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=192', 11, 'acf-field', '', 0),
(193, 1, '2017-12-19 11:45:42', '2017-12-19 11:45:42', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Step 5', '_copy', 'publish', 'closed', 'closed', '', 'field_5a38faffbf072', '', '', '2017-12-19 11:45:42', '2017-12-19 11:45:42', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=193', 15, 'acf-field', '', 0),
(194, 1, '2017-12-19 11:45:42', '2017-12-19 11:45:42', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:124:\"We off a number of cost effective ways to promote your listings and encrease its exposure. Take a look at our options below.\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Promote Title', 'promote_title', 'publish', 'closed', 'closed', '', 'field_5a38fb18bf073', '', '', '2017-12-19 11:45:42', '2017-12-19 11:45:42', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=194', 16, 'acf-field', '', 0),
(195, 1, '2017-12-19 11:48:02', '2017-12-19 11:48:02', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:166:\"Your ad will be highlighted and be identified as one of our Premium Listings. This feature is for users who are looking to promote their ad and increase its exposure.\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Premium Description', 'premium_description', 'publish', 'closed', 'closed', '', 'field_5a38fbea81a69', '', '', '2017-12-19 11:48:02', '2017-12-19 11:48:02', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=195', 17, 'acf-field', '', 0),
(196, 1, '2017-12-19 11:49:55', '2017-12-19 11:49:55', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:250:\"Your ad will be highlighted and be identified as one of our Featured Listings. Featured Listings are randomly selected and posted at the top of each search page. This feature is for users who are looking to promote their ad and increase its exposure.\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Featured Description', 'featured_description', 'publish', 'closed', 'closed', '', 'field_5a38fc7af0cef', '', '', '2017-12-19 11:55:19', '2017-12-19 11:55:19', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=196', 19, 'acf-field', '', 0),
(197, 1, '2017-12-19 11:50:50', '2017-12-19 11:50:50', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:80:\"Your property will be directly linked to an external website using the following\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'URL Description', 'url_description', 'publish', 'closed', 'closed', '', 'field_5a38fce6d0f36', '', '', '2017-12-19 11:55:19', '2017-12-19 11:55:19', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=197', 21, 'acf-field', '', 0),
(198, 1, '2017-12-19 11:51:54', '2017-12-19 11:51:54', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:52:\"Your ad will be automatically bumped up every 7 days\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Bump Description', 'bump_description', 'publish', 'closed', 'closed', '', 'field_5a38fd2f7c1d5', '', '', '2017-12-19 11:55:19', '2017-12-19 11:55:19', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=198', 23, 'acf-field', '', 0),
(199, 1, '2017-12-19 11:54:35', '2017-12-19 11:54:35', 'a:13:{s:4:\"type\";s:6:\"number\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:5;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}', 'Premium Price', 'premium_price', 'publish', 'closed', 'closed', '', 'field_5a38fd8db4c2a', '', '', '2017-12-19 11:55:19', '2017-12-19 11:55:19', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=199', 18, 'acf-field', '', 0),
(200, 1, '2017-12-19 11:54:35', '2017-12-19 11:54:35', 'a:13:{s:4:\"type\";s:6:\"number\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:10;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}', 'Featured Price', 'featured_price', 'publish', 'closed', 'closed', '', 'field_5a38fdb3b4c2b', '', '', '2017-12-19 11:55:19', '2017-12-19 11:55:19', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=200', 20, 'acf-field', '', 0),
(201, 1, '2017-12-19 11:54:35', '2017-12-19 11:54:35', 'a:13:{s:4:\"type\";s:6:\"number\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:3;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}', 'URL Price', 'url_price', 'publish', 'closed', 'closed', '', 'field_5a38fdccb4c2c', '', '', '2017-12-19 11:55:19', '2017-12-19 11:55:19', '', 144, 'http://localhost/zaivia/?post_type=acf-field&#038;p=201', 22, 'acf-field', '', 0),
(202, 1, '2017-12-19 11:54:35', '2017-12-19 11:54:35', 'a:13:{s:4:\"type\";s:6:\"number\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";i:10;s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:4:\"step\";s:0:\"\";}', 'Bump Price', 'bump_price', 'publish', 'closed', 'closed', '', 'field_5a38fdeab4c2d', '', '', '2017-12-19 11:54:35', '2017-12-19 11:54:35', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=202', 24, 'acf-field', '', 0),
(232, 1, '2017-12-27 00:15:20', '2017-12-27 00:15:20', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Step 6', '', 'publish', 'closed', 'closed', '', 'field_5a42e5b37f091', '', '', '2017-12-27 00:15:20', '2017-12-27 00:15:20', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=232', 25, 'acf-field', '', 0),
(233, 1, '2017-12-27 00:15:20', '2017-12-27 00:15:20', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:17:\"Listing Activated\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'step6_title', 'publish', 'closed', 'closed', '', 'field_5a42e5ca7f092', '', '', '2017-12-27 00:15:20', '2017-12-27 00:15:20', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=233', 26, 'acf-field', '', 0),
(234, 1, '2017-12-27 00:15:20', '2017-12-27 00:15:20', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:44:\"Thank you for adding your property to Zaivia\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Text', 'step6_text', 'publish', 'closed', 'closed', '', 'field_5a42e5f47f093', '', '', '2017-12-27 00:15:20', '2017-12-27 00:15:20', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=234', 27, 'acf-field', '', 0),
(235, 1, '2017-12-27 00:15:20', '2017-12-27 00:15:20', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:17:\"Back To My Zaivia\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Button', 'step6_button', 'publish', 'closed', 'closed', '', 'field_5a42e6077f094', '', '', '2017-12-27 00:15:20', '2017-12-27 00:15:20', '', 144, 'http://localhost/zaivia/?post_type=acf-field&p=235', 28, 'acf-field', '', 0),
(236, 1, '2017-12-28 11:41:40', '2017-12-28 11:41:40', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-12-28 12:32:56', '2017-12-28 12:32:56', '', 0, 'http://localhost/zaivia/?page_id=236', 0, 'page', '', 0),
(237, 1, '2017-12-28 11:41:40', '2017-12-28 11:41:40', '', 'Home', '', 'inherit', 'closed', 'closed', '', '236-revision-v1', '', '', '2017-12-28 11:41:40', '2017-12-28 11:41:40', '', 236, 'http://localhost/zaivia/2017/12/28/236-revision-v1/', 0, 'revision', '', 0),
(241, 1, '2017-12-28 11:49:06', '2017-12-28 11:49:06', '', 'Home', '', 'inherit', 'closed', 'closed', '', '236-revision-v1', '', '', '2017-12-28 11:49:06', '2017-12-28 11:49:06', '', 236, 'http://localhost/zaivia/2017/12/28/236-revision-v1/', 0, 'revision', '', 0),
(242, 1, '2017-12-28 12:18:44', '2017-12-28 12:18:44', '', 'Rent', '', 'publish', 'closed', 'closed', '', 'rent', '', '', '2018-01-22 14:35:00', '2018-01-22 14:35:00', '', 0, 'http://localhost/zaivia/?page_id=242', 0, 'page', '', 0),
(243, 1, '2017-12-28 12:18:44', '2017-12-28 12:18:44', '', 'Rent', '', 'inherit', 'closed', 'closed', '', '242-revision-v1', '', '', '2017-12-28 12:18:44', '2017-12-28 12:18:44', '', 242, 'http://localhost/zaivia/2017/12/28/242-revision-v1/', 0, 'revision', '', 0),
(246, 1, '2017-12-28 12:22:21', '2017-12-28 12:22:21', ' ', '', '', 'publish', 'closed', 'closed', '', '246', '', '', '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 0, 'http://localhost/zaivia/?p=246', 2, 'nav_menu_item', '', 0),
(247, 1, '2017-12-28 12:29:19', '2017-12-28 12:29:19', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Pages', '', 'publish', 'closed', 'closed', '', 'field_5a44e2dae5f9e', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=247', 23, 'acf-field', '', 0),
(248, 1, '2017-12-28 12:29:19', '2017-12-28 12:29:19', 'a:11:{s:4:\"type\";s:9:\"page_link\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'Buy', 'page_buy', 'publish', 'closed', 'closed', '', 'field_5a44e2e8e5f9f', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=248', 24, 'acf-field', '', 0),
(249, 1, '2017-12-28 12:29:19', '2017-12-28 12:29:19', 'a:11:{s:4:\"type\";s:9:\"page_link\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'Rent', 'page_rent', 'publish', 'closed', 'closed', '', 'field_5a44e347e5fa0', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=249', 25, 'acf-field', '', 0),
(250, 1, '2017-12-28 12:29:19', '2017-12-28 12:29:19', 'a:11:{s:4:\"type\";s:9:\"page_link\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'My Listings', 'page_mylistings', 'publish', 'closed', 'closed', '', 'field_5a44e35ce5fa1', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=250', 26, 'acf-field', '', 0),
(251, 1, '2017-12-28 12:29:19', '2017-12-28 12:29:19', 'a:11:{s:4:\"type\";s:9:\"page_link\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'Post Listing', 'page_postlisting', 'publish', 'closed', 'closed', '', 'field_5a44e390e5fa3', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=251', 27, 'acf-field', '', 0),
(252, 1, '2017-12-28 12:32:44', '2017-12-28 12:32:44', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:13:\"Contest Rules\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Banner Text', 'banner_text', 'publish', 'closed', 'closed', '', 'field_5a44e456976d4', '', '', '2018-02-26 10:17:05', '2018-02-26 10:17:05', '', 43, 'http://localhost/zaivia/?post_type=acf-field&#038;p=252', 6, 'acf-field', '', 0),
(255, 1, '2017-12-29 07:10:22', '2017-12-29 07:10:22', '', 'My Profile', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2017-12-29 07:10:22', '2017-12-29 07:10:22', '', 80, 'http://localhost/zaivia/2017/12/29/80-revision-v1/', 0, 'revision', '', 0),
(256, 1, '2017-12-29 07:11:13', '2017-12-29 07:11:13', ' ', '', '', 'publish', 'closed', 'closed', '', '256', '', '', '2017-12-29 07:11:13', '2017-12-29 07:11:13', '', 0, 'http://localhost/zaivia/?p=256', 1, 'nav_menu_item', '', 0),
(257, 1, '2017-12-29 07:11:13', '2017-12-29 07:11:13', ' ', '', '', 'publish', 'closed', 'closed', '', '257', '', '', '2017-12-29 07:11:13', '2017-12-29 07:11:13', '', 0, 'http://localhost/zaivia/?p=257', 2, 'nav_menu_item', '', 0),
(258, 1, '2017-12-29 07:11:14', '2017-12-29 07:11:14', ' ', '', '', 'publish', 'closed', 'closed', '', '258', '', '', '2017-12-29 07:11:14', '2017-12-29 07:11:14', '', 0, 'http://localhost/zaivia/?p=258', 3, 'nav_menu_item', '', 0),
(259, 1, '2018-01-02 23:53:57', '2018-01-02 23:53:57', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3', '', '', '2018-01-02 23:53:57', '2018-01-02 23:53:57', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3.jpg', 0, 'attachment', 'image/jpeg', 0),
(260, 1, '2018-01-02 23:54:02', '2018-01-02 23:54:02', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving', '', '', '2018-01-02 23:54:02', '2018-01-02 23:54:02', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving.png', 0, 'attachment', 'image/png', 0),
(261, 1, '2018-01-03 00:08:46', '2018-01-03 00:08:46', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-2', '', '', '2018-01-03 00:08:46', '2018-01-03 00:08:46', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(262, 1, '2018-01-03 00:21:33', '2018-01-03 00:21:33', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-2', '', '', '2018-01-03 00:21:33', '2018-01-03 00:21:33', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-1.png', 0, 'attachment', 'image/png', 0),
(263, 1, '2018-01-03 01:13:21', '2018-01-03 01:13:21', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-3', '', '', '2018-01-03 01:13:21', '2018-01-03 01:13:21', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-2.png', 0, 'attachment', 'image/png', 0),
(264, 1, '2018-01-03 01:13:26', '2018-01-03 01:13:26', '', '01-01-003_I_DesignNam1', '', 'inherit', 'open', 'closed', '', '01-01-003_i_designnam1', '', '', '2018-01-03 01:13:26', '2018-01-03 01:13:26', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01-003_I_DesignNam1.jpg', 0, 'attachment', 'image/jpeg', 0),
(265, 1, '2018-01-03 01:16:11', '2018-01-03 01:16:11', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-3', '', '', '2018-01-03 01:16:11', '2018-01-03 01:16:11', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(266, 1, '2018-01-03 01:16:13', '2018-01-03 01:16:13', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-4', '', '', '2018-01-03 01:16:13', '2018-01-03 01:16:13', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-3.png', 0, 'attachment', 'image/png', 0),
(268, 1, '2018-01-03 14:24:11', '2018-01-03 14:24:11', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-4', '', '', '2018-01-03 14:24:11', '2018-01-03 14:24:11', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(269, 1, '2018-01-03 14:24:16', '2018-01-03 14:24:16', '', '08-28-12-14-CF_I2_DesignName', '', 'inherit', 'open', 'closed', '', '08-28-12-14-cf_i2_designname', '', '', '2018-01-03 14:24:16', '2018-01-03 14:24:16', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-28-12-14-CF_I2_DesignName.jpg', 0, 'attachment', 'image/jpeg', 0),
(270, 1, '2018-01-04 10:10:11', '2018-01-04 10:10:11', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-5', '', '', '2018-01-04 10:10:11', '2018-01-04 10:10:11', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(271, 1, '2018-01-04 10:10:15', '2018-01-04 10:10:15', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-5', '', '', '2018-01-04 10:10:15', '2018-01-04 10:10:15', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-4.png', 0, 'attachment', 'image/png', 0),
(272, 1, '2018-01-05 11:10:55', '2018-01-05 11:10:55', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-6', '', '', '2018-01-05 11:10:55', '2018-01-05 11:10:55', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-5.png', 0, 'attachment', 'image/png', 0),
(273, 1, '2018-01-05 11:11:00', '2018-01-05 11:11:00', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-6', '', '', '2018-01-05 11:11:00', '2018-01-05 11:11:00', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(274, 1, '2018-01-05 12:01:20', '2018-01-05 12:01:20', '', 'DB_doc', '', 'inherit', 'open', 'closed', '', 'db_doc', '', '', '2018-01-05 12:01:20', '2018-01-05 12:01:20', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/DB_doc.docx', 0, 'attachment', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 0),
(275, 1, '2018-01-05 12:01:33', '2018-01-05 12:01:33', '', '01-01-003_I_DesignNam1', '', 'inherit', 'open', 'closed', '', '01-01-003_i_designnam1-2', '', '', '2018-01-05 12:01:33', '2018-01-05 12:01:33', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01-003_I_DesignNam1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(276, 1, '2018-01-05 12:01:37', '2018-01-05 12:01:37', '', 'Без имени-1', '', 'inherit', 'open', 'closed', '', '%d0%b1%d0%b5%d0%b7-%d0%b8%d0%bc%d0%b5%d0%bd%d0%b8-1', '', '', '2018-01-05 12:01:37', '2018-01-05 12:01:37', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/Без-имени-1.png', 0, 'attachment', 'image/png', 0),
(277, 1, '2018-01-05 12:01:46', '2018-01-05 12:01:46', '', '01-01-003_I_DesignName', '', 'inherit', 'open', 'closed', '', '01-01-003_i_designname', '', '', '2018-01-05 12:01:46', '2018-01-05 12:01:46', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01-003_I_DesignName.jpg', 0, 'attachment', 'image/jpeg', 0),
(278, 1, '2018-01-05 12:04:43', '2018-01-05 12:04:43', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-7', '', '', '2018-01-05 12:04:43', '2018-01-05 12:04:43', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(279, 1, '2018-01-05 12:04:45', '2018-01-05 12:04:45', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-7', '', '', '2018-01-05 12:04:45', '2018-01-05 12:04:45', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-6.png', 0, 'attachment', 'image/png', 0),
(280, 1, '2018-01-05 12:07:37', '2018-01-05 12:07:37', '', 'DB_doc', '', 'inherit', 'open', 'closed', '', 'db_doc-2', '', '', '2018-01-05 12:07:37', '2018-01-05 12:07:37', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/DB_doc-1.docx', 0, 'attachment', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 0),
(281, 1, '2018-01-05 12:07:48', '2018-01-05 12:07:48', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-8', '', '', '2018-01-05 12:07:48', '2018-01-05 12:07:48', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-7.png', 0, 'attachment', 'image/png', 0),
(282, 1, '2018-01-05 12:07:51', '2018-01-05 12:07:51', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-8', '', '', '2018-01-05 12:07:51', '2018-01-05 12:07:51', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(283, 1, '2018-01-05 12:07:54', '2018-01-05 12:07:54', '', 'Без имени-1', '', 'inherit', 'open', 'closed', '', '%d0%b1%d0%b5%d0%b7-%d0%b8%d0%bc%d0%b5%d0%bd%d0%b8-1-2', '', '', '2018-01-05 12:07:54', '2018-01-05 12:07:54', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/Без-имени-1-1.png', 0, 'attachment', 'image/png', 0),
(284, 1, '2018-01-05 12:08:54', '2018-01-05 12:08:54', '', 'profile 1', '', 'inherit', 'open', 'closed', '', 'profile-1', '', '', '2018-01-05 12:08:54', '2018-01-05 12:08:54', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/profile-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(285, 1, '2018-01-05 12:08:59', '2018-01-05 12:08:59', '', 'logo 1', '', 'inherit', 'open', 'closed', '', 'logo-1', '', '', '2018-01-05 12:08:59', '2018-01-05 12:08:59', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/logo-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(286, 1, '2018-01-05 12:14:57', '2018-01-05 12:14:57', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-9', '', '', '2018-01-05 12:14:57', '2018-01-05 12:14:57', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/01-01_B1_3-8.jpg', 0, 'attachment', 'image/jpeg', 0),
(287, 1, '2018-01-05 12:15:01', '2018-01-05 12:15:01', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-9', '', '', '2018-01-05 12:15:01', '2018-01-05 12:15:01', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/08-30_B_driving-8.png', 0, 'attachment', 'image/png', 0),
(288, 1, '2018-01-08 07:55:18', '2018-01-08 07:55:18', '', 'Buy', '', 'publish', 'closed', 'closed', '', 'buy', '', '', '2018-01-16 09:52:27', '2018-01-16 09:52:27', '', 0, 'http://localhost/zaivia/?page_id=288', 0, 'page', '', 0),
(289, 1, '2018-01-08 07:55:18', '2018-01-08 07:55:18', '', 'Buy', '', 'inherit', 'closed', 'closed', '', '288-revision-v1', '', '', '2018-01-08 07:55:18', '2018-01-08 07:55:18', '', 288, 'http://localhost/zaivia/2018/01/08/288-revision-v1/', 0, 'revision', '', 0),
(290, 1, '2018-01-08 07:55:42', '2018-01-08 07:55:42', ' ', '', '', 'publish', 'closed', 'closed', '', '290', '', '', '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 0, 'http://localhost/zaivia/?p=290', 1, 'nav_menu_item', '', 0),
(297, 1, '2018-01-11 13:26:57', '2018-01-11 13:26:57', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'key', 'key', 'publish', 'closed', 'closed', '', 'field_5a5765ec731cd', '', '', '2018-01-11 13:26:57', '2018-01-11 13:26:57', '', 131, 'http://localhost/zaivia/?post_type=acf-field&p=297', 1, 'acf-field', '', 0),
(298, 1, '2018-01-11 13:26:57', '2018-01-11 13:26:57', 'a:11:{s:4:\"type\";s:10:\"true_false\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:0;s:2:\"ui\";i:0;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}', 'Show in filter', 'show_in_filter', 'publish', 'closed', 'closed', '', 'field_5a5765fd731ce', '', '', '2018-01-11 13:26:57', '2018-01-11 13:26:57', '', 131, 'http://localhost/zaivia/?post_type=acf-field&p=298', 2, 'acf-field', '', 0),
(299, 1, '2018-01-11 16:58:39', '2018-01-11 16:58:39', '', 'photo', '', 'inherit', 'open', 'closed', '', 'photo', '', '', '2018-01-11 16:58:39', '2018-01-11 16:58:39', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/photo.jpg', 0, 'attachment', 'image/jpeg', 0),
(300, 1, '2018-01-11 16:59:05', '2018-01-11 16:59:05', '', 'ea-skynet-logo-200x200-9272', '', 'inherit', 'open', 'closed', '', 'ea-skynet-logo-200x200-9272', '', '', '2018-01-11 16:59:05', '2018-01-11 16:59:05', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/ea-skynet-logo-200x200-9272-1.png', 0, 'attachment', 'image/png', 0),
(301, 1, '2018-01-11 17:00:05', '2018-01-11 17:00:05', '', 'john', '', 'inherit', 'open', 'closed', '', 'john', '', '', '2018-01-11 17:00:05', '2018-01-11 17:00:05', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/john.jpg', 0, 'attachment', 'image/jpeg', 0),
(302, 1, '2018-01-11 17:00:11', '2018-01-11 17:00:11', '', 'ea-skynet-logo-200x200-9272', '', 'inherit', 'open', 'closed', '', 'ea-skynet-logo-200x200-9272-2', '', '', '2018-01-11 17:00:11', '2018-01-11 17:00:11', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/ea-skynet-logo-200x200-9272-2.png', 0, 'attachment', 'image/png', 0),
(303, 1, '2018-01-11 17:00:50', '2018-01-11 17:00:50', '', 'Pasquia_Gate', '', 'inherit', 'open', 'closed', '', 'pasquia_gate', '', '', '2018-01-11 17:00:50', '2018-01-11 17:00:50', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/Pasquia_Gate.jpg', 0, 'attachment', 'image/jpeg', 0),
(304, 1, '2018-01-11 17:00:50', '2018-01-11 17:00:50', '', 'IMG_9419_20_21_tonemapped', '', 'inherit', 'open', 'closed', '', 'img_9419_20_21_tonemapped', '', '', '2018-01-11 17:00:50', '2018-01-11 17:00:50', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9419_20_21_tonemapped.jpg', 0, 'attachment', 'image/jpeg', 0),
(305, 1, '2018-01-16 08:36:38', '2018-01-16 08:36:38', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"post_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:22:\"page-templates/buy.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Ads', 'ads', 'publish', 'closed', 'closed', '', 'group_5a5db8913c3a1', '', '', '2018-01-16 09:51:12', '2018-01-16 09:51:12', '', 0, 'http://localhost/zaivia/?post_type=acf-field-group&#038;p=305', 0, 'acf-field-group', '', 0),
(306, 1, '2018-01-16 08:36:38', '2018-01-16 08:36:38', 'a:16:{s:4:\"type\";s:5:\"image\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'List Banner Image', 'list_banner_image', 'publish', 'closed', 'closed', '', 'field_5a5db8d8af3e3', '', '', '2018-01-16 08:36:38', '2018-01-16 08:36:38', '', 305, 'http://localhost/zaivia/?post_type=acf-field&p=306', 0, 'acf-field', '', 0),
(307, 1, '2018-01-16 08:36:38', '2018-01-16 08:36:38', 'a:8:{s:4:\"type\";s:3:\"url\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}', 'List Banner Url', 'list_banner_url', 'publish', 'closed', 'closed', '', 'field_5a5db96caf3e4', '', '', '2018-01-16 08:36:38', '2018-01-16 08:36:38', '', 305, 'http://localhost/zaivia/?post_type=acf-field&p=307', 1, 'acf-field', '', 0),
(308, 1, '2018-01-16 08:38:47', '2018-01-16 08:38:47', '', 'b1', '', 'inherit', 'open', 'closed', '', 'b1', '', '', '2018-01-16 08:38:55', '2018-01-16 08:38:55', '', 288, 'http://localhost/zaivia/wp-content/uploads/2018/01/b1.jpg', 0, 'attachment', 'image/jpeg', 0),
(309, 1, '2018-01-16 08:38:48', '2018-01-16 08:38:48', '', 'b2', '', 'inherit', 'open', 'closed', '', 'b2', '', '', '2018-01-16 08:38:48', '2018-01-16 08:38:48', '', 288, 'http://localhost/zaivia/wp-content/uploads/2018/01/b2.jpg', 0, 'attachment', 'image/jpeg', 0),
(310, 1, '2018-01-16 08:39:21', '2018-01-16 08:39:21', '', 'Buy', '', 'inherit', 'closed', 'closed', '', '288-revision-v1', '', '', '2018-01-16 08:39:21', '2018-01-16 08:39:21', '', 288, 'http://localhost/zaivia/2018/01/16/288-revision-v1/', 0, 'revision', '', 0),
(311, 1, '2018-01-16 09:51:12', '2018-01-16 09:51:12', 'a:16:{s:4:\"type\";s:5:\"image\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:9:\"thumbnail\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Sidebar Banner Image', 'sidebar_banner_image', 'publish', 'closed', 'closed', '', 'field_5a5dca7125533', '', '', '2018-01-16 09:51:12', '2018-01-16 09:51:12', '', 305, 'http://localhost/zaivia/?post_type=acf-field&p=311', 2, 'acf-field', '', 0),
(312, 1, '2018-01-16 09:51:12', '2018-01-16 09:51:12', 'a:8:{s:4:\"type\";s:3:\"url\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}', 'Sidebar Banner Url', 'sidebar_banner_url', 'publish', 'closed', 'closed', '', 'field_5a5dcafd25534', '', '', '2018-01-16 09:51:12', '2018-01-16 09:51:12', '', 305, 'http://localhost/zaivia/?post_type=acf-field&p=312', 3, 'acf-field', '', 0),
(313, 1, '2018-01-16 09:51:57', '2018-01-16 09:51:57', '', 'b2', '', 'inherit', 'open', 'closed', '', 'b2-2', '', '', '2018-01-16 09:52:00', '2018-01-16 09:52:00', '', 288, 'http://localhost/zaivia/wp-content/uploads/2018/01/b2-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(314, 1, '2018-01-16 09:52:27', '2018-01-16 09:52:27', '', 'Buy', '', 'inherit', 'closed', 'closed', '', '288-revision-v1', '', '', '2018-01-16 09:52:27', '2018-01-16 09:52:27', '', 288, 'http://localhost/zaivia/2018/01/16/288-revision-v1/', 0, 'revision', '', 0),
(315, 1, '2018-01-18 10:55:40', '2018-01-18 10:55:40', '', 'Listing', '', 'publish', 'closed', 'closed', '', 'listing', '', '', '2018-01-18 21:17:00', '2018-01-18 21:17:00', '', 0, 'http://localhost/zaivia/?page_id=315', 0, 'page', '', 0),
(316, 1, '2018-01-18 10:55:40', '2018-01-18 10:55:40', '', 'Listing', '', 'inherit', 'closed', 'closed', '', '315-revision-v1', '', '', '2018-01-18 10:55:40', '2018-01-18 10:55:40', '', 315, 'http://localhost/zaivia/2018/01/18/315-revision-v1/', 0, 'revision', '', 0),
(317, 1, '2018-01-19 11:58:06', '2018-01-19 11:58:06', '', 'fl1', '', 'inherit', 'open', 'closed', '', 'fl1', '', '', '2018-01-19 11:58:06', '2018-01-19 11:58:06', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/fl1.jpg', 0, 'attachment', 'image/jpeg', 0),
(318, 1, '2018-01-19 11:58:43', '2018-01-19 11:58:43', '', 'IMG_9437', '', 'inherit', 'open', 'closed', '', 'img_9437', '', '', '2018-01-19 11:58:43', '2018-01-19 11:58:43', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9437.jpg', 0, 'attachment', 'image/jpeg', 0),
(319, 1, '2018-01-29 00:05:38', '2018-01-29 00:05:38', '', 'IMG_9436', '', 'inherit', 'open', 'closed', '', 'img_9436', '', '', '2018-01-29 00:05:38', '2018-01-29 00:05:38', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9436.jpg', 0, 'attachment', 'image/jpeg', 0),
(320, 1, '2018-01-29 00:05:38', '2018-01-29 00:05:38', '', 'IMG_9435', '', 'inherit', 'open', 'closed', '', 'img_9435', '', '', '2018-01-29 00:05:38', '2018-01-29 00:05:38', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9435.jpg', 0, 'attachment', 'image/jpeg', 0),
(321, 1, '2018-01-29 00:05:38', '2018-01-29 00:05:38', '', 'IMG_9436_7_8_tonemapped', '', 'inherit', 'open', 'closed', '', 'img_9436_7_8_tonemapped', '', '', '2018-01-29 00:05:38', '2018-01-29 00:05:38', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9436_7_8_tonemapped.jpg', 0, 'attachment', 'image/jpeg', 0),
(322, 1, '2018-01-29 00:05:47', '2018-01-29 00:05:47', '', 'IMG_9428', '', 'inherit', 'open', 'closed', '', 'img_9428', '', '', '2018-01-29 00:05:47', '2018-01-29 00:05:47', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9428.jpg', 0, 'attachment', 'image/jpeg', 0),
(323, 1, '2018-01-29 00:05:47', '2018-01-29 00:05:47', '', 'IMG_9427_8_9_tonemapped', '', 'inherit', 'open', 'closed', '', 'img_9427_8_9_tonemapped', '', '', '2018-01-29 00:05:47', '2018-01-29 00:05:47', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9427_8_9_tonemapped.jpg', 0, 'attachment', 'image/jpeg', 0),
(324, 1, '2018-01-29 00:12:24', '2018-01-29 00:12:24', '', 'IMG_9433', '', 'inherit', 'open', 'closed', '', 'img_9433', '', '', '2018-01-29 00:12:24', '2018-01-29 00:12:24', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9433.jpg', 0, 'attachment', 'image/jpeg', 0),
(325, 1, '2018-01-29 00:12:24', '2018-01-29 00:12:24', '', 'IMG_9437', '', 'inherit', 'open', 'closed', '', 'img_9437-2', '', '', '2018-01-29 00:12:24', '2018-01-29 00:12:24', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/IMG_9437-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(326, 1, '2018-01-29 00:12:28', '2018-01-29 00:12:28', '', '15-let-svadby-06', '', 'inherit', 'open', 'closed', '', '15-let-svadby-06', '', '', '2018-01-29 00:12:28', '2018-01-29 00:12:28', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/15-let-svadby-06.jpg', 0, 'attachment', 'image/jpeg', 0),
(327, 1, '2018-01-29 00:12:28', '2018-01-29 00:12:28', '', '0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full', '', 'inherit', 'open', 'closed', '', '0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full', '', '', '2018-01-29 00:12:28', '2018-01-29 00:12:28', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/01/0-02-05-2ef671432aac922020153a191fa1509a1361bf3d624a6a79737dcc1aaee88820_full-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(328, 1, '2018-01-30 11:34:02', '2018-01-30 11:34:02', 'Account Activated', 'Account Activated', '', 'publish', 'closed', 'closed', '', 'account-activated', '', '', '2018-01-30 11:34:02', '2018-01-30 11:34:02', '', 0, 'http://localhost/zaivia/?page_id=328', 0, 'page', '', 0),
(329, 1, '2018-01-30 11:34:02', '2018-01-30 11:34:02', 'Account Activated', 'Account Activated', '', 'inherit', 'closed', 'closed', '', '328-revision-v1', '', '', '2018-01-30 11:34:02', '2018-01-30 11:34:02', '', 328, 'http://localhost/zaivia/2018/01/30/328-revision-v1/', 0, 'revision', '', 0),
(330, 1, '2018-01-30 11:34:40', '2018-01-30 11:34:40', 'a:11:{s:4:\"type\";s:9:\"page_link\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";a:0:{}s:10:\"allow_null\";i:0;s:14:\"allow_archives\";i:1;s:8:\"multiple\";i:0;}', 'Account Activated', 'page_account_activated', 'publish', 'closed', 'closed', '', 'field_5a7058361678f', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=330', 28, 'acf-field', '', 0),
(331, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Create Account', '', 'publish', 'closed', 'closed', '', 'field_5a705875b4c57', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=331', 29, 'acf-field', '', 0),
(332, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'create_account_title', 'publish', 'closed', 'closed', '', 'field_5a705885b4c58', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=332', 30, 'acf-field', '', 0),
(333, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Text', 'create_account_text', 'publish', 'closed', 'closed', '', 'field_5a705890b4c59', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=333', 31, 'acf-field', '', 0),
(334, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Subscribe', 'create_account_subscribe', 'publish', 'closed', 'closed', '', 'field_5a70589db4c5a', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=334', 32, 'acf-field', '', 0),
(335, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Terms', 'create_account_terms', 'publish', 'closed', 'closed', '', 'field_5a7058a9b4c5b', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=335', 33, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(336, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:8:{s:4:\"type\";s:3:\"tab\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Resore Password', '', 'publish', 'closed', 'closed', '', 'field_5a7058b7b4c5c', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=336', 34, 'acf-field', '', 0),
(337, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'restore_pass_title', 'publish', 'closed', 'closed', '', 'field_5a7058bfb4c5d', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=337', 35, 'acf-field', '', 0),
(338, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Text', 'restore_pass_text', 'publish', 'closed', 'closed', '', 'field_5a7058d8b4c5e', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=338', 36, 'acf-field', '', 0),
(339, 1, '2018-01-30 11:37:31', '2018-01-30 11:37:31', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Confirmation Text', 'restore_confirmation', 'publish', 'closed', 'closed', '', 'field_5a7058e8b4c5f', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&#038;p=339', 37, 'acf-field', '', 0),
(340, 1, '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 'My Zaivia', '', 'publish', 'closed', 'closed', '', 'my-zaivia', '', '', '2018-01-30 12:07:53', '2018-01-30 12:07:53', '', 0, 'http://localhost/zaivia/?p=340', 7, 'nav_menu_item', '', 0),
(341, 2, '2018-02-18 12:57:41', '2018-02-18 12:57:41', '', '08-30_B1_Driving', '', 'inherit', 'open', 'closed', '', '08-30_b1_driving', '', '', '2018-02-18 12:57:41', '2018-02-18 12:57:41', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/08-30_B1_Driving.jpg', 0, 'attachment', 'image/jpeg', 0),
(342, 2, '2018-02-18 12:57:45', '2018-02-18 12:57:45', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-10', '', '', '2018-02-18 12:57:45', '2018-02-18 12:57:45', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/08-30_B_driving.png', 0, 'attachment', 'image/png', 0),
(343, 2, '2018-02-18 13:00:16', '2018-02-18 13:00:16', '', 'Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15', 'The archetypal male face of beauty according to a new scientific study to mark the launch of the Samsung Galaxy S6.  Embargoed to 00.01hrs 30th March 2015.', 'inherit', 'open', 'closed', '', 'archetypal-male-face-of-beauty-embargoed-to-00-01hrs-30-03-15', '', '', '2018-02-18 13:00:16', '2018-02-18 13:00:16', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/Archetypal-Male-Face-of-Beauty-embargoed-to-00.01hrs-30.03.15.jpg', 0, 'attachment', 'image/jpeg', 0),
(344, 2, '2018-02-18 13:00:23', '2018-02-18 13:00:23', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-11', '', '', '2018-02-18 13:00:23', '2018-02-18 13:00:23', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/08-30_B_driving-1.png', 0, 'attachment', 'image/png', 0),
(345, 2, '2018-02-18 14:21:19', '2018-02-18 14:21:19', '', '01-01_B1_(3)', '', 'inherit', 'open', 'closed', '', '01-01_b1_3-10', '', '', '2018-02-18 14:21:19', '2018-02-18 14:21:19', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/01-01_B1_3.jpg', 0, 'attachment', 'image/jpeg', 0),
(346, 2, '2018-02-18 14:21:22', '2018-02-18 14:21:22', '', '08-30_B_driving', '', 'inherit', 'open', 'closed', '', '08-30_b_driving-12', '', '', '2018-02-18 14:21:22', '2018-02-18 14:21:22', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/08-30_B_driving-2.png', 0, 'attachment', 'image/png', 0),
(347, 1, '2018-02-22 12:01:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-02-22 12:01:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/zaivia/?p=347', 0, 'post', '', 0),
(349, 1, '2018-02-24 20:07:26', '2018-02-24 20:07:26', '', '66-01-E_Photo', '', 'inherit', 'open', 'closed', '', '66-01-e_photo', '', '', '2018-02-24 20:07:26', '2018-02-24 20:07:26', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/66-01-E_Photo.jpg', 0, 'attachment', 'image/jpeg', 0),
(351, 1, '2018-02-25 11:23:55', '2018-02-25 11:23:55', '', 'Магнитофон', '', 'inherit', 'open', 'closed', '', '%d0%bc%d0%b0%d0%b3%d0%bd%d0%b8%d1%82%d0%be%d1%84%d0%be%d0%bd', '', '', '2018-02-25 11:23:55', '2018-02-25 11:23:55', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/Магнитофон.docx', 0, 'attachment', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 0),
(352, 1, '2018-02-25 13:18:06', '2018-02-25 13:18:06', '', '50-11-006-HLF_Photo', '', 'inherit', 'open', 'closed', '', '50-11-006-hlf_photo', '', '', '2018-02-25 13:18:06', '2018-02-25 13:18:06', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/50-11-006-HLF_Photo.jpg', 0, 'attachment', 'image/jpeg', 0),
(355, 1, '2018-02-25 13:18:24', '2018-02-25 13:18:24', '', 'Web', '', 'inherit', 'open', 'closed', '', 'web', '', '', '2018-02-25 13:18:24', '2018-02-25 13:18:24', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/01-01.jpg', 0, 'attachment', 'image/jpeg', 0),
(356, 1, '2018-02-26 07:59:21', '2018-02-26 07:59:21', '', '66-01-E_Photo', '', 'inherit', 'open', 'closed', '', '66-01-e_photo-2', '', '', '2018-02-26 07:59:21', '2018-02-26 07:59:21', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/66-01-E_Photo-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(357, 1, '2018-02-26 07:59:25', '2018-02-26 07:59:25', '', 'Web', '', 'inherit', 'open', 'closed', '', 'web-2', '', '', '2018-02-26 07:59:25', '2018-02-26 07:59:25', '', 0, 'http://localhost/zaivia/wp-content/uploads/2018/02/01-01-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(358, 1, '2018-02-26 10:15:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-02-26 10:15:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/zaivia/?post_type=acf-field-group&p=358', 0, 'acf-field-group', '', 0),
(359, 1, '2018-02-26 10:16:49', '2018-02-26 10:16:49', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:22:\"Make Yourself at Home!\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Search Title', 'search_title', 'publish', 'closed', 'closed', '', 'field_5a93de5d3b0fe', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&p=359', 5, 'acf-field', '', 0),
(360, 1, '2018-02-26 10:16:49', '2018-02-26 10:16:49', 'a:11:{s:4:\"type\";s:4:\"text\";s:5:\"value\";N;s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:48:\"Search for properties for sale or rent in Canada\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Search Text', 'search_text', 'publish', 'closed', 'closed', '', 'field_5a93de733b0ff', '', '', '2018-02-26 10:16:49', '2018-02-26 10:16:49', '', 38, 'http://localhost/zaivia/?post_type=acf-field&p=360', 6, 'acf-field', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_termmeta`
--

DROP TABLE IF EXISTS `wp_termmeta`;
CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'mainmenu', 'mainmenu', 0),
(3, 'footermenu1', 'footermenu1', 0),
(4, 'footermenu2', 'footermenu2', 0),
(6, 'accountmenu', 'accountmenu', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(14, 2, 0),
(15, 2, 0),
(19, 2, 0),
(20, 2, 0),
(24, 3, 0),
(25, 3, 0),
(34, 4, 0),
(35, 4, 0),
(36, 4, 0),
(37, 4, 0),
(246, 2, 0),
(256, 6, 0),
(257, 6, 0),
(258, 6, 0),
(290, 2, 0),
(340, 2, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 7),
(3, 3, 'nav_menu', '', 0, 2),
(4, 4, 'nav_menu', '', 0, 4),
(6, 6, 'nav_menu', '', 0, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', 'Test'),
(3, 1, 'last_name', 'qwqw'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '347'),
(17, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'wp_user-settings', 'editor=html&libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1511655078'),
(21, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(23, 1, 'nav_menu_recently_edited', '2'),
(24, 1, 'closedpostboxes_toplevel_page_theme-general-settings', 'a:0:{}'),
(25, 1, 'metaboxhidden_toplevel_page_theme-general-settings', 'a:0:{}'),
(26, 1, 'acf_user_settings', 'a:0:{}'),
(27, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(28, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(30, 1, 'session_tokens', 'a:2:{s:64:\"d5a9ada2587477af5afb6f350208d51c21e52af59c5f1f18027c53bf883a1cfa\";a:4:{s:10:\"expiration\";i:1519655217;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36\";s:5:\"login\";i:1518445617;}s:64:\"720939fb7d4ef1600436dd85642fccf42166aa849f9899ec9d3745ef5d4e4335\";a:4:{s:10:\"expiration\";i:1519668134;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36\";s:5:\"login\";i:1519495334;}}'),
(38, 2, 'nickname', 'tester@test.com'),
(39, 2, 'first_name', ''),
(40, 2, 'last_name', ''),
(41, 2, 'description', ''),
(42, 2, 'rich_editing', 'true'),
(43, 2, 'syntax_highlighting', 'true'),
(44, 2, 'comment_shortcuts', 'false'),
(45, 2, 'admin_color', 'fresh'),
(46, 2, 'use_ssl', '0'),
(47, 2, 'show_admin_bar_front', 'false'),
(48, 2, 'locale', ''),
(49, 2, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(50, 2, 'wp_user_level', '0'),
(51, 2, 'dismissed_wp_pointers', ''),
(52, 2, 'phone', '1234567890'),
(53, 2, 'phone_type', 'cell'),
(54, 2, 'subscribe', '1'),
(55, 2, 'first_name', 'Test'),
(56, 2, 'last_name', 'Tester'),
(60, 2, 'favorite_listing', 'a:1:{i:278;i:278;}'),
(63, 2, 'recently_listing', 'a:1:{i:0;s:3:\"278\";}'),
(64, 2, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(65, 1, 'default_password_nag', ''),
(66, 1, 'favorite_listing', 'a:2:{i:284;i:284;i:285;i:285;}'),
(67, 1, 'recently_listing', 'a:3:{i:0;s:3:\"285\";i:1;s:3:\"284\";i:2;s:3:\"286\";}'),
(68, 1, 'syntax_highlighting', 'true'),
(69, 1, 'phone', '123123'),
(70, 1, 'phone_type', 'cell'),
(71, 1, 'ccs', 'a:1:{i:0;a:8:{s:15:\"cardholder_name\";s:3:\"qqq\";s:9:\"cc_number\";s:16:\"4111111111111111\";s:14:\"cc_number_safe\";s:16:\"XXXXXXXXXXXX1111\";s:7:\"cc_type\";s:10:\"mastercard\";s:9:\"cc_date_m\";s:1:\"3\";s:9:\"cc_date_y\";s:4:\"2021\";s:3:\"ccv\";s:3:\"123\";s:6:\"cc_uid\";s:11:\"11519635163\";}}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Дамп данных таблицы `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$Bdgdn9LY.iFxDosMNYUokUkl3ghCtv1', 'admin', 'smanic80@gmail.com', '', '2017-10-23 22:58:31', '', 0, 'Test qwqw'),
(2, 'tester@test.com', '$P$BoBlBv/vHUXs41LPGA8nK3c/yo1z4n1', 'testertest-com', 'tester@test.com', '', '2018-02-18 12:52:11', '', 0, 'Test Tester');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Индексы таблицы `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Индексы таблицы `wp_listings`
--
ALTER TABLE `wp_listings`
  ADD PRIMARY KEY (`listing_id`),
  ADD KEY `abc` (`MLSNumber`);

--
-- Индексы таблицы `wp_listing_contact`
--
ALTER TABLE `wp_listing_contact`
  ADD PRIMARY KEY (`contact_id`),
  ADD KEY `listing_id` (`listing_id`);

--
-- Индексы таблицы `wp_listing_features`
--
ALTER TABLE `wp_listing_features`
  ADD PRIMARY KEY (`feature_id`),
  ADD KEY `listing_id` (`listing_id`);

--
-- Индексы таблицы `wp_listing_file`
--
ALTER TABLE `wp_listing_file`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `wp_listing_file_ibfk_1` (`listing_id`),
  ADD KEY `media_id` (`media_id`);

--
-- Индексы таблицы `wp_listing_openhouse`
--
ALTER TABLE `wp_listing_openhouse`
  ADD PRIMARY KEY (`openhouse_id`),
  ADD KEY `listing_id` (`listing_id`);

--
-- Индексы таблицы `wp_listing_rent`
--
ALTER TABLE `wp_listing_rent`
  ADD PRIMARY KEY (`rent_id`),
  ADD KEY `listing_id` (`listing_id`);

--
-- Индексы таблицы `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Индексы таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Индексы таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Индексы таблицы `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Индексы таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Индексы таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_listings`
--
ALTER TABLE `wp_listings`
  MODIFY `listing_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=287;
--
-- AUTO_INCREMENT для таблицы `wp_listing_contact`
--
ALTER TABLE `wp_listing_contact`
  MODIFY `contact_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;
--
-- AUTO_INCREMENT для таблицы `wp_listing_features`
--
ALTER TABLE `wp_listing_features`
  MODIFY `feature_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `wp_listing_file`
--
ALTER TABLE `wp_listing_file`
  MODIFY `file_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT для таблицы `wp_listing_openhouse`
--
ALTER TABLE `wp_listing_openhouse`
  MODIFY `openhouse_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT для таблицы `wp_listing_rent`
--
ALTER TABLE `wp_listing_rent`
  MODIFY `rent_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1635;
--
-- AUTO_INCREMENT для таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1092;
--
-- AUTO_INCREMENT для таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=361;
--
-- AUTO_INCREMENT для таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT для таблицы `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `wp_listing_contact`
--
ALTER TABLE `wp_listing_contact`
  ADD CONSTRAINT `wp_listing_contact_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `wp_listings` (`listing_id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `wp_listing_features`
--
ALTER TABLE `wp_listing_features`
  ADD CONSTRAINT `wp_listing_features_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `wp_listings` (`listing_id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `wp_listing_file`
--
ALTER TABLE `wp_listing_file`
  ADD CONSTRAINT `wp_listing_file_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `wp_listings` (`listing_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wp_listing_file_ibfk_2` FOREIGN KEY (`media_id`) REFERENCES `wp_posts` (`ID`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `wp_listing_openhouse`
--
ALTER TABLE `wp_listing_openhouse`
  ADD CONSTRAINT `wp_listing_openhouse_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `wp_listings` (`listing_id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `wp_listing_rent`
--
ALTER TABLE `wp_listing_rent`
  ADD CONSTRAINT `wp_listing_rent_ibfk_1` FOREIGN KEY (`listing_id`) REFERENCES `wp_listings` (`listing_id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
